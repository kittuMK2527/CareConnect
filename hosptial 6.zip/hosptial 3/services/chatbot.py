"""
AI Chatbot Service for Healthcare Assistance
Provides intelligent responses about drugs, prescriptions, and healthcare
"""

import re
from typing import Dict, List, Optional
from services.drug_matcher import DrugMatcher
from services.generic_suggester import GenericSuggester
from database.db_manager import DatabaseManager


class HealthcareChatbot:
    """
    AI-powered chatbot for healthcare assistance
    Handles drug queries, prescription help, and general healthcare questions
    """
    
    def __init__(self, drug_matcher: DrugMatcher, generic_suggester: GenericSuggester, db_manager: DatabaseManager):
        self.drug_matcher = drug_matcher
        self.generic_suggester = generic_suggester
        self.db_manager = db_manager
        self.conversation_history = []
        
        # Intent patterns
        self.intent_patterns = {
            'drug_search': [
                r'search.*drug', r'find.*drug', r'looking.*for.*drug',
                r'where.*find', r'available.*drug', r'stock.*drug'
            ],
            'drug_info': [
                r'what.*is', r'tell.*about', r'information.*about',
                r'details.*of', r'know.*about', r'explain'
            ],
            'generic_alternative': [
                r'generic', r'cheaper', r'alternative', r'jan.*aushadhi',
                r'low.*cost', r'affordable', r'save.*money'
            ],
            'prescription_help': [
                r'prescription', r'verify', r'check.*prescription',
                r'fraud', r'valid', r'authentic'
            ],
            'stock_check': [
                r'stock', r'available', r'in.*stock', r'have.*stock',
                r'pharmacy.*has', r'where.*buy'
            ],
            'side_effects': [
                r'side.*effect', r'adverse', r'risk', r'warning',
                r'precaution', r'safe'
            ],
            'dosage': [
                r'dosage', r'how.*much', r'how.*many', r'take',
                r'consume', r'dose'
            ],
            'greeting': [
                r'hello', r'hi', r'hey', r'good.*morning', r'good.*evening',
                r'help', r'assist'
            ],
            'goodbye': [
                r'bye', r'goodbye', r'thank.*you', r'thanks', r'see.*you'
            ]
        }
    
    def process_message(self, message: str, user_id: str = 'anonymous', context: Dict = None) -> Dict:
        """
        Process user message and generate response
        Returns: chatbot response with intent and data
        """
        message_lower = message.lower().strip()
        
        # Detect intent
        intent = self._detect_intent(message_lower)
        
        # Generate response based on intent
        response = self._generate_response(message_lower, intent, context)
        
        # Store conversation
        self.conversation_history.append({
            'user_id': user_id,
            'message': message,
            'intent': intent,
            'response': response['text'],
            'timestamp': self._get_timestamp()
        })
        
        return {
            'intent': intent,
            'response': response,
            'confidence': response.get('confidence', 0.8)
        }
    
    def _detect_intent(self, message: str) -> str:
        """Detect user intent from message"""
        scores = {}
        
        for intent, patterns in self.intent_patterns.items():
            score = 0
            for pattern in patterns:
                if re.search(pattern, message, re.IGNORECASE):
                    score += 1
            if score > 0:
                scores[intent] = score
        
        if scores:
            return max(scores, key=scores.get)
        return 'general'
    
    def _generate_response(self, message: str, intent: str, context: Dict = None) -> Dict:
        """Generate response based on intent"""
        
        if intent == 'greeting':
            return {
                'text': "Hello! I'm your healthcare assistant. I can help you with:\n"
                       "• Drug information and availability\n"
                       "• Generic alternatives (Jan Aushadhi)\n"
                       "• Prescription verification\n"
                       "• Stock availability\n"
                       "• Dosage and side effects\n\n"
                       "How can I assist you today?",
                'confidence': 1.0,
                'type': 'text'
            }
        
        elif intent == 'drug_search':
            # Extract drug name from message
            drug_name = self._extract_drug_name(message)
            if drug_name:
                results = self.drug_matcher.search_drugs(drug_name, limit=5)
                if results:
                    response_text = f"Found {len(results)} results for '{drug_name}':\n\n"
                    for i, drug in enumerate(results[:3], 1):
                        response_text += f"{i}. **{drug['name']}** ({drug.get('category', 'Unknown')})\n"
                        if drug.get('schedule'):
                            response_text += f"   Schedule: {drug['schedule']}\n"
                        response_text += "\n"
                    response_text += "Would you like more details about any of these?"
                    return {
                        'text': response_text,
                        'data': results,
                        'confidence': 0.9,
                        'type': 'drug_list'
                    }
                else:
                    return {
                        'text': f"Sorry, I couldn't find '{drug_name}' in our database. "
                               "Please check the spelling or try a different drug name.",
                        'confidence': 0.7,
                        'type': 'text'
                    }
            else:
                return {
                    'text': "I'd be happy to help you search for a drug! "
                           "Please tell me the name of the drug you're looking for.",
                    'confidence': 0.8,
                    'type': 'text'
                }
        
        elif intent == 'generic_alternative':
            drug_name = self._extract_drug_name(message)
            if drug_name:
                match = self.drug_matcher.match_drug(drug_name)
                if match:
                    generics = self.generic_suggester.suggest_generics(match['drug_id'])
                    if generics:
                        response_text = f"Here are affordable generic alternatives for **{match['name']}**:\n\n"
                        for alt in generics:
                            response_text += f"• **{alt['name']}** - ₹{alt['price']} "
                            response_text += f"(Save {alt.get('savings', '50-80%')})\n"
                        response_text += "\nThese are available through Jan Aushadhi scheme."
                        return {
                            'text': response_text,
                            'data': {'original': match, 'alternatives': generics},
                            'confidence': 0.9,
                            'type': 'generic_alternatives'
                        }
                    else:
                        return {
                            'text': f"Sorry, I couldn't find generic alternatives for {match['name']} at the moment.",
                            'confidence': 0.7,
                            'type': 'text'
                        }
                else:
                    return {
                        'text': f"Could you please provide the exact drug name? I couldn't match '{drug_name}'.",
                        'confidence': 0.6,
                        'type': 'text'
                    }
            else:
                return {
                    'text': "I can help you find generic alternatives! Please tell me the name of the drug.",
                    'confidence': 0.8,
                    'type': 'text'
                }
        
        elif intent == 'stock_check':
            drug_name = self._extract_drug_name(message)
            location = self._extract_location(message) or (context.get('location') if context else None)
            
            if drug_name:
                match = self.drug_matcher.match_drug(drug_name)
                if match:
                    # In production, check actual stock
                    response_text = f"To check stock availability for **{match['name']}**, "
                    if location:
                        response_text += f"please upload a prescription or use the stock checker with location: {location}."
                    else:
                        response_text += "please provide your location or upload a prescription."
                    return {
                        'text': response_text,
                        'data': {'drug': match, 'location': location},
                        'confidence': 0.8,
                        'type': 'stock_info'
                    }
                else:
                    return {
                        'text': f"Could you please provide the exact drug name? I couldn't match '{drug_name}'.",
                        'confidence': 0.6,
                        'type': 'text'
                    }
            else:
                return {
                    'text': "I can help you check stock availability! Please tell me the drug name and your location.",
                    'confidence': 0.8,
                    'type': 'text'
                }
        
        elif intent == 'prescription_help':
            return {
                'text': "I can help you verify prescriptions! Here's what I can do:\n\n"
                       "• **Upload a prescription** - I'll analyze it for fraud detection\n"
                       "• **Check authenticity** - Verify doctor and hospital details\n"
                       "• **Drug extraction** - Identify all drugs from the prescription\n"
                       "• **Stock availability** - Find nearby pharmacies with stock\n\n"
                       "Would you like to upload a prescription image?",
                'confidence': 0.9,
                'type': 'text'
            }
        
        elif intent == 'drug_info':
            drug_name = self._extract_drug_name(message)
            if drug_name:
                match = self.drug_matcher.match_drug(drug_name)
                if match:
                    response_text = f"**{match['name']}** Information:\n\n"
                    response_text += f"• Category: {match.get('category', 'Unknown')}\n"
                    if match.get('schedule'):
                        response_text += f"• Schedule: {match['schedule']}\n"
                    response_text += f"• Generic: {'Yes' if match.get('is_generic') else 'No'}\n"
                    if match.get('brand_names'):
                        response_text += f"• Brand names: {', '.join(match['brand_names'][:3])}\n"
                    return {
                        'text': response_text,
                        'data': match,
                        'confidence': 0.9,
                        'type': 'drug_info'
                    }
                else:
                    return {
                        'text': f"Sorry, I don't have detailed information about '{drug_name}' in my database.",
                        'confidence': 0.6,
                        'type': 'text'
                    }
            else:
                return {
                    'text': "I'd be happy to provide drug information! Please tell me the name of the drug.",
                    'confidence': 0.8,
                    'type': 'text'
                }
        
        elif intent == 'side_effects':
            drug_name = self._extract_drug_name(message)
            if drug_name:
                return {
                    'text': f"For detailed side effects and precautions of **{drug_name}**, "
                           "please consult with a qualified doctor or pharmacist. "
                           "I can help you find the drug and check availability though!",
                    'confidence': 0.8,
                    'type': 'text'
                }
            else:
                return {
                    'text': "For side effects information, please provide the drug name. "
                           "Note: Always consult a doctor for medical advice.",
                    'confidence': 0.8,
                    'type': 'text'
                }
        
        elif intent == 'dosage':
            return {
                'text': "Dosage information should always be confirmed by a doctor or pharmacist. "
                       "The correct dosage depends on:\n"
                       "• Patient's age and weight\n"
                       "• Medical condition\n"
                       "• Other medications\n"
                       "• Medical history\n\n"
                       "Please consult your doctor for accurate dosage instructions.",
                'confidence': 0.9,
                'type': 'text'
            }
        
        elif intent == 'goodbye':
            return {
                'text': "You're welcome! If you need any more help with drugs, prescriptions, or healthcare, "
                       "feel free to ask. Stay healthy! 😊",
                'confidence': 1.0,
                'type': 'text'
            }
        
        else:
            # General/unknown intent
            return {
                'text': "I'm here to help with healthcare-related questions! I can assist with:\n"
                       "• Drug search and information\n"
                       "• Generic alternatives\n"
                       "• Prescription verification\n"
                       "• Stock availability\n\n"
                       "What would you like to know?",
                'confidence': 0.7,
                'type': 'text'
            }
    
    def _extract_drug_name(self, message: str) -> Optional[str]:
        """Extract drug name from message"""
        # Common drug name patterns
        words = message.split()
        
        # Look for capitalized words (common drug names)
        for i, word in enumerate(words):
            if word and word[0].isupper() and len(word) > 3:
                # Check if it's a known drug
                potential_name = word
                if i + 1 < len(words) and words[i + 1][0].isupper():
                    potential_name = f"{word} {words[i + 1]}"
                
                # Try to match
                match = self.drug_matcher.match_drug(potential_name)
                if match:
                    return potential_name
        
        # Try common drug keywords
        drug_keywords = ['paracetamol', 'amoxicillin', 'metformin', 'insulin', 
                        'omeprazole', 'atorvastatin', 'amlodipine']
        for keyword in drug_keywords:
            if keyword in message.lower():
                return keyword
        
        return None
    
    def _extract_location(self, message: str) -> Optional[str]:
        """Extract location from message"""
        # Common Indian cities
        cities = ['delhi', 'mumbai', 'bangalore', 'chennai', 'kolkata', 
                 'hyderabad', 'pune', 'ahmedabad', 'jaipur']
        message_lower = message.lower()
        for city in cities:
            if city in message_lower:
                return city.capitalize()
        return None
    
    def _get_timestamp(self) -> str:
        """Get current timestamp"""
        from datetime import datetime
        return datetime.now().isoformat()
    
    def get_conversation_history(self, user_id: str = 'anonymous', limit: int = 10) -> List[Dict]:
        """Get conversation history for a user"""
        user_history = [h for h in self.conversation_history if h['user_id'] == user_id]
        return user_history[-limit:]

