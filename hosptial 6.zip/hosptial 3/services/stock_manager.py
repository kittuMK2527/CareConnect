"""
Real-time Stock Management Service
Handles stock availability checking and updates
"""

from typing import Dict, List, Optional
from datetime import datetime
import math


class StockManager:
    """
    Manages pharmacy stock and availability checking
    """
    
    def __init__(self, db_manager):
        self.db_manager = db_manager
    
    def check_availability(self, drug_id: str, location: str, radius_km: float = 10) -> Dict:
        """
        Check drug availability in nearby pharmacies
        Returns: stock information with nearby pharmacies
        """
        # Get all pharmacies with stock
        pharmacies = self.db_manager.get_pharmacies_with_stock(drug_id)
        
        # Filter by location (if location provided)
        nearby_pharmacies = []
        if location:
            # In production, use actual geolocation API
            # For now, simulate distance calculation
            for pharmacy in pharmacies:
                # Simulate distance (in production, use geopy or similar)
                distance = self._calculate_distance(location, pharmacy.get('location', ''))
                if distance <= radius_km:
                    pharmacy['distance_km'] = distance
                    nearby_pharmacies.append(pharmacy)
        else:
            nearby_pharmacies = pharmacies
        
        # Sort by distance
        nearby_pharmacies.sort(key=lambda x: x.get('distance_km', 0))
        
        # Calculate total available stock
        total_stock = sum(p.get('stock_quantity', 0) for p in nearby_pharmacies)
        
        return {
            'drug_id': drug_id,
            'available': total_stock > 0,
            'total_stock': total_stock,
            'pharmacies': nearby_pharmacies[:10],  # Top 10 nearest
            'count': len(nearby_pharmacies),
            'last_updated': datetime.now().isoformat()
        }
    
    def _calculate_distance(self, loc1: str, loc2: str) -> float:
        """
        Calculate distance between two locations
        In production, use geolocation API (geopy, Google Maps API, etc.)
        """
        # Simulated distance calculation
        # In production, implement actual geolocation
        return abs(hash(loc1) % 20) + abs(hash(loc2) % 20) / 2
    
    def update_stock(self, pharmacy_id: str, drug_id: str, quantity: int):
        """Update pharmacy stock"""
        self.db_manager.update_pharmacy_stock(pharmacy_id, drug_id, quantity)
    
    def get_stock_history(self, drug_id: str, days: int = 30) -> List[Dict]:
        """Get stock history for a drug"""
        return self.db_manager.get_stock_history(drug_id, days)

