"""
OCR Service for Prescription Processing
Multi-stage pipeline with preprocessing and text extraction
"""

import cv2
import numpy as np
import pytesseract
from PIL import Image
import re
from typing import Dict, List, Tuple
import os


class OCRService:
    """
    Advanced OCR pipeline with preprocessing
    Implements grayscale, binarization, and fuzzy matching
    """
    
    def __init__(self):
        # Set Tesseract path (adjust for your system)
        # For Linux/Mac: usually '/usr/bin/tesseract'
        # For Windows: usually 'C:\\Program Files\\Tesseract-OCR\\tesseract.exe'
        # pytesseract.pytesseract.tesseract_cmd = '/usr/bin/tesseract'
        pass
    
    def process_prescription(self, image_path: str) -> Dict:
        """
        Process prescription image through OCR pipeline
        Returns: extracted text and metadata
        """
        try:
            # Load image
            image = cv2.imread(image_path)
            if image is None:
                # Try with PIL as fallback
                try:
                    pil_image = Image.open(image_path)
                    image = cv2.cvtColor(np.array(pil_image), cv2.COLOR_RGB2BGR)
                except Exception as e:
                    raise ValueError(f"Could not load image: {image_path}. Error: {str(e)}")
            
            # Preprocessing pipeline with multiple attempts
            processed_images = self._preprocess_multiple(image)
            
            # Try OCR with different preprocessing
            best_result = None
            best_confidence = 0
            
            for proc_img, method in processed_images:
                try:
                    # OCR extraction
                    ocr_text = pytesseract.image_to_string(proc_img, lang='eng', config='--psm 6')
                    ocr_data = pytesseract.image_to_data(proc_img, lang='eng', output_type=pytesseract.Output.DICT, config='--psm 6')
                    
                    # Calculate confidence
                    confidences = [int(float(conf)) for conf in ocr_data['conf'] if int(float(conf)) > 0]
                    avg_confidence = sum(confidences) / len(confidences) if confidences else 0
                    
                    if avg_confidence > best_confidence:
                        best_confidence = avg_confidence
                        best_result = {
                            'raw_text': ocr_text,
                            'confidence': avg_confidence,
                            'method': method
                        }
                except Exception as e:
                    print(f"OCR attempt with {method} failed: {e}")
                    continue
            
            # If no good result, try with original image
            if not best_result or best_confidence < 30:
                try:
                    ocr_text = pytesseract.image_to_string(image, lang='eng', config='--psm 6')
                    ocr_data = pytesseract.image_to_data(image, lang='eng', output_type=pytesseract.Output.DICT, config='--psm 6')
                    confidences = [int(float(conf)) for conf in ocr_data['conf'] if int(float(conf)) > 0]
                    avg_confidence = sum(confidences) / len(confidences) if confidences else 40
                    best_result = {
                        'raw_text': ocr_text,
                        'confidence': avg_confidence,
                        'method': 'original'
                    }
                except:
                    # Fallback: return minimal data
                    return {
                        'raw_text': '',
                        'confidence': 20,
                        'doctor_name': '',
                        'hospital_id': '',
                        'date': '',
                        'drugs': [],
                        'dosage': [],
                        'patient_name': '',
                        'error': 'OCR processing failed, please try a clearer image'
                    }
            
            # Extract structured information
            extracted_data = self._extract_structured_data(best_result['raw_text'])
            
            return {
                'raw_text': best_result['raw_text'],
                'confidence': best_result['confidence'],
                'doctor_name': extracted_data.get('doctor_name', ''),
                'hospital_id': extracted_data.get('hospital_id', ''),
                'hospital_name': extracted_data.get('hospital_name', ''),
                'address': extracted_data.get('address', ''),
                'phone': extracted_data.get('phone', ''),
                'date': extracted_data.get('date', ''),
                'drugs': extracted_data.get('drugs', []),
                'dosage': extracted_data.get('dosage', []),
                'patient_name': extracted_data.get('patient_name', ''),
                'processing_method': best_result.get('method', 'standard')
            }
        
        except Exception as e:
            # Return error result instead of raising
            return {
                'raw_text': '',
                'confidence': 0,
                'doctor_name': '',
                'hospital_id': '',
                'date': '',
                'drugs': [],
                'dosage': [],
                'patient_name': '',
                'error': f'OCR Error: {str(e)}'
            }
    
    def _preprocess_image(self, image: np.ndarray) -> np.ndarray:
        """
        Multi-stage preprocessing pipeline
        1. Grayscale conversion
        2. Noise reduction
        3. Binarization
        4. Morphological operations
        """
        # Convert to grayscale
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image.copy()
        
        # Noise reduction using Gaussian blur
        denoised = cv2.GaussianBlur(gray, (5, 5), 0)
        
        # Adaptive thresholding for binarization
        # Better than simple thresholding for varying lighting
        binary = cv2.adaptiveThreshold(
            denoised, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY, 11, 2
        )
        
        # Morphological operations to clean up
        kernel = np.ones((2, 2), np.uint8)
        cleaned = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel)
        
        return cleaned
    
    def _preprocess_multiple(self, image: np.ndarray) -> List[tuple]:
        """Try multiple preprocessing methods for best OCR results"""
        results = []
        
        # Method 1: Standard preprocessing
        try:
            processed = self._preprocess_image(image)
            results.append((processed, 'standard'))
        except:
            pass
        
        # Method 2: High contrast
        try:
            if len(image.shape) == 3:
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            else:
                gray = image.copy()
            # Increase contrast
            clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
            enhanced = clahe.apply(gray)
            binary = cv2.adaptiveThreshold(enhanced, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)
            results.append((binary, 'high_contrast'))
        except:
            pass
        
        # Method 3: Denoised only
        try:
            if len(image.shape) == 3:
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            else:
                gray = image.copy()
            denoised = cv2.fastNlMeansDenoising(gray, None, 10, 7, 21)
            results.append((denoised, 'denoised'))
        except:
            pass
        
        # Method 4: Original grayscale
        try:
            if len(image.shape) == 3:
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            else:
                gray = image.copy()
            results.append((gray, 'grayscale'))
        except:
            pass
        
        return results if results else [(image, 'original')]
    
    def _deskew(self, image: np.ndarray) -> np.ndarray:
        """Deskew rotated text"""
        # Find all non-zero points
        coords = np.column_stack(np.where(image > 0))
        
        if len(coords) == 0:
            return image
        
        # Find minimum area rectangle
        angle = cv2.minAreaRect(coords)[-1]
        
        # Correct angle
        if angle < -45:
            angle = -(90 + angle)
        else:
            angle = -angle
        
        # Rotate image
        (h, w) = image.shape[:2]
        center = (w // 2, h // 2)
        M = cv2.getRotationMatrix2D(center, angle, 1.0)
        rotated = cv2.warpAffine(image, M, (w, h),
                                 flags=cv2.INTER_CUBIC,
                                 borderMode=cv2.BORDER_REPLICATE)
        
        return rotated
    
    def _extract_structured_data(self, text: str) -> Dict:
        """Extract structured data from OCR text with improved patterns"""
        extracted = {
            'doctor_name': '',
            'hospital_id': '',
            'hospital_name': '',
            'address': '',
            'phone': '',
            'date': '',
            'drugs': [],
            'dosage': [],
            'patient_name': ''
        }
        
        if not text or len(text.strip()) < 3:
            return extracted
        
        lines = [line.strip() for line in text.split('\n') if line.strip()]
        
        # Extract doctor name (multiple patterns)
        doctor_patterns = [
            r'Dr\.?\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)',
            r'Doctor[:\s]+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)',
            r'Dr\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)',
            r'([A-Z][a-z]+\s+[A-Z][a-z]+)\s*MD',
            r'([A-Z][a-z]+\s+[A-Z][a-z]+)\s*MBBS'
        ]
        
        for line in lines:
            for pattern in doctor_patterns:
                match = re.search(pattern, line, re.IGNORECASE)
                if match:
                    name = match.group(1).strip()
                    if len(name) > 2 and name not in ['Name', 'Date', 'Patient']:
                        extracted['doctor_name'] = name
                        break
            if extracted['doctor_name']:
                break
        
        # Extract hospital/clinic name or ID
        hospital_patterns = [
            r'(Hospital|Clinic|Medical|Center)[:\s]+([A-Z0-9\s\-]+)',
            r'(REG|REGISTRATION|ID|LIC)[\s\-:]+([A-Z0-9\-]+)',
            r'([A-Z][a-z]+\s+(?:Hospital|Clinic|Medical|Center))',
            r'Hospital[:\s]+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)'
        ]
        
        for line in lines:
            for pattern in hospital_patterns:
                match = re.search(pattern, line, re.IGNORECASE)
                if match:
                    hospital = match.group(2 if len(match.groups()) > 1 else 1).strip()
                    if len(hospital) > 2:
                        extracted['hospital_id'] = hospital
                        extracted['hospital_name'] = hospital
                        break
            if extracted['hospital_id']:
                break
        
        # Extract address
        address_patterns = [
            r'Address[:\s]+([A-Z0-9\s,\-\.]+)',
            r'([0-9]+\s+[A-Z][a-z]+\s+(?:Street|Road|Avenue|Lane|Drive))',
            r'([A-Z][a-z]+,\s*[A-Z][a-z]+,\s*[A-Z][a-z]+)',
            r'([A-Z][a-z]+\s+[A-Z][a-z]+,\s*[A-Z][a-z]+)'
        ]
        
        for line in lines:
            for pattern in address_patterns:
                match = re.search(pattern, line, re.IGNORECASE)
                if match:
                    address = match.group(1 if len(match.groups()) > 0 else 0).strip()
                    if len(address) > 5:
                        extracted['address'] = address
                        break
            if extracted['address']:
                break
        
        # Extract phone number
        phone_patterns = [
            r'Phone[:\s]+([\+0-9\s\-\(\)]+)',
            r'([\+]?91[\s\-]?[0-9]{10})',
            r'([0-9]{3}[\s\-]?[0-9]{3}[\s\-]?[0-9]{4})',
            r'([\+]?[0-9]{1,3}[\s\-]?[0-9]{3,4}[\s\-]?[0-9]{3,4}[\s\-]?[0-9]{3,4})'
        ]
        
        for line in lines:
            for pattern in phone_patterns:
                match = re.search(pattern, line, re.IGNORECASE)
                if match:
                    phone = match.group(1 if len(match.groups()) > 0 else 0).strip()
                    if len(phone) > 5:
                        extracted['phone'] = phone
                        break
            if extracted['phone']:
                break
        
        # Extract date (multiple formats)
        date_patterns = [
            r'\d{1,2}[/-]\d{1,2}[/-]\d{2,4}',
            r'\d{4}[/-]\d{1,2}[/-]\d{1,2}',
            r'\d{1,2}\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{2,4}',
            r'(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{1,2},?\s+\d{2,4}',
            r'Date[:\s]+(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})'
        ]
        
        for line in lines:
            for pattern in date_patterns:
                match = re.search(pattern, line, re.IGNORECASE)
                if match:
                    date_str = match.group(0).strip()
                    if len(date_str) > 4:
                        extracted['date'] = date_str
                        break
            if extracted['date']:
                break
        
        # Extract patient name
        patient_patterns = [
            r'Patient[:\s]+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)',
            r'Name[:\s]+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)',
            r'([A-Z][a-z]+\s+[A-Z][a-z]+)\s*Age'
        ]
        
        for line in lines:
            for pattern in patient_patterns:
                match = re.search(pattern, line, re.IGNORECASE)
                if match:
                    name = match.group(1).strip()
                    if len(name) > 2:
                        extracted['patient_name'] = name
                        break
            if extracted['patient_name']:
                break
        
        # Extract drug names (improved patterns)
        drug_keywords = ['tablet', 'tab', 'capsule', 'cap', 'syrup', 'injection', 'inj', 'mg', 'ml', 'g', 'drops', 'cream', 'ointment']
        common_drugs = ['paracetamol', 'amoxicillin', 'metformin', 'insulin', 'omeprazole', 'atorvastatin', 
                       'amlodipine', 'aspirin', 'ibuprofen', 'diclofenac', 'cefixime', 'azithromycin',
                       'levofloxacin', 'ciprofloxacin', 'doxycycline', 'augmentin', 'crocin', 'dolo']
        
        # Method 1: Look for drug keywords with names
        for line in lines:
            line_lower = line.lower()
            # Check if line contains drug keywords
            if any(keyword in line_lower for keyword in drug_keywords):
                # Extract words before keywords
                words = line.split()
                for i, word in enumerate(words):
                    word_lower = word.lower()
                    if any(kw in word_lower for kw in drug_keywords):
                        # Get words before this keyword
                        if i > 0:
                            potential_drug = ' '.join(words[:i]).strip()
                            if len(potential_drug) > 2:
                                extracted['drugs'].append(potential_drug)
                        # Also check if any word matches common drugs
                        for common_drug in common_drugs:
                            if common_drug in line_lower:
                                extracted['drugs'].append(common_drug.capitalize())
                        break
        
        # Method 2: Look for capitalized words that might be drug names
        if not extracted['drugs']:
            for line in lines:
                # Skip lines that are clearly not drugs
                if any(skip in line.lower() for skip in ['doctor', 'patient', 'date', 'hospital', 'clinic', 'address', 'phone']):
                    continue
                
                # Find capitalized words (potential drug names)
                words = re.findall(r'\b[A-Z][a-z]{3,}\b', line)
                for word in words:
                    # Skip common non-drug words
                    skip_words = ['Doctor', 'Patient', 'Date', 'Hospital', 'Clinic', 'Medical', 'Center', 
                                 'Name', 'Age', 'Address', 'Phone', 'Prescription', 'Medicine']
                    if word not in skip_words and len(word) > 3:
                        extracted['drugs'].append(word)
        
        # Method 3: Extract from raw text if still no drugs found
        if not extracted['drugs']:
            # Look for any word that might be a drug (3+ letters, capitalized)
            all_words = re.findall(r'\b[A-Z][a-z]{2,}\b', text)
            for word in all_words[:10]:  # Limit to first 10
                if word not in ['Doctor', 'Patient', 'Date', 'Hospital', 'Clinic', 'Medical', 'Center']:
                    extracted['drugs'].append(word)
        
        # Remove duplicates and clean
        extracted['drugs'] = list(dict.fromkeys(extracted['drugs']))[:10]  # Max 10 drugs
        
        return extracted

