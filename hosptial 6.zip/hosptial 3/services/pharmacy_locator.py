"""
Enhanced Pharmacy Locator Service
Provides detailed pharmacy/shop information by city/location
"""

from typing import Dict, List
import random


class PharmacyLocator:
    """
    Enhanced pharmacy locator with detailed shop information
    Provides comprehensive details about pharmacies in a given city
    """
    
    def __init__(self):
        # Sample pharmacy database (in production, this would be from database)
        self.pharmacy_database = self._initialize_pharmacy_data()
    
    def _initialize_pharmacy_data(self) -> Dict:
        """Initialize sample pharmacy data for major Indian cities"""
        cities = {
            'bangalore': [
                {
                    'name': 'Apollo Pharmacy',
                    'branch': 'Koramangala',
                    'address': '123 Koramangala 5th Block, Bangalore, Karnataka 560095',
                    'phone': '+91-80-12345678',
                    'email': 'koramangala@apollopharmacy.in',
                    'timings': '24/7',
                    'services': ['Home Delivery', 'Online Orders', 'Prescription Filling', 'Health Checkups'],
                    'rating': 4.5,
                    'total_reviews': 1250,
                    'delivery_available': True,
                    'accepts_insurance': True,
                    'parking_available': True,
                    'wheelchair_accessible': True,
                    'stock_status': 'Well Stocked',
                    'average_wait_time': '10 mins',
                    'contact_person': 'Mr. Rajesh Kumar',
                    'license_number': 'KA-BLR-2024-001',
                    'established_year': 2010
                },
                {
                    'name': 'MedPlus',
                    'branch': 'Indiranagar',
                    'address': '456 Indiranagar 100 Feet Road, Bangalore, Karnataka 560038',
                    'phone': '+91-80-23456789',
                    'email': 'indiranagar@medplus.in',
                    'timings': '8:00 AM - 11:00 PM',
                    'services': ['Home Delivery', 'Online Orders', 'Health Products', 'Lab Tests'],
                    'rating': 4.3,
                    'total_reviews': 890,
                    'delivery_available': True,
                    'accepts_insurance': True,
                    'parking_available': False,
                    'wheelchair_accessible': True,
                    'stock_status': 'Well Stocked',
                    'average_wait_time': '15 mins',
                    'contact_person': 'Ms. Priya Sharma',
                    'license_number': 'KA-BLR-2024-002',
                    'established_year': 2012
                },
                {
                    'name': 'Wellness Forever',
                    'branch': 'Whitefield',
                    'address': '789 Whitefield Main Road, Bangalore, Karnataka 560066',
                    'phone': '+91-80-34567890',
                    'email': 'whitefield@wellnessforever.com',
                    'timings': '9:00 AM - 10:00 PM',
                    'services': ['Prescription Filling', 'Health Consultation', 'Medical Equipment'],
                    'rating': 4.6,
                    'total_reviews': 567,
                    'delivery_available': True,
                    'accepts_insurance': False,
                    'parking_available': True,
                    'wheelchair_accessible': True,
                    'stock_status': 'Moderate Stock',
                    'average_wait_time': '8 mins',
                    'contact_person': 'Dr. Anil Verma',
                    'license_number': 'KA-BLR-2024-003',
                    'established_year': 2015
                }
            ],
            'mumbai': [
                {
                    'name': 'Apollo Pharmacy',
                    'branch': 'Andheri West',
                    'address': '101 Lokhandwala Complex, Andheri West, Mumbai, Maharashtra 400053',
                    'phone': '+91-22-12345678',
                    'email': 'andheri@apollopharmacy.in',
                    'timings': '24/7',
                    'services': ['Home Delivery', 'Online Orders', 'Prescription Filling', 'Health Checkups'],
                    'rating': 4.7,
                    'total_reviews': 2340,
                    'delivery_available': True,
                    'accepts_insurance': True,
                    'parking_available': True,
                    'wheelchair_accessible': True,
                    'stock_status': 'Excellent Stock',
                    'average_wait_time': '5 mins',
                    'contact_person': 'Mr. Suresh Patel',
                    'license_number': 'MH-MUM-2024-001',
                    'established_year': 2008
                },
                {
                    'name': '1mg',
                    'branch': 'Bandra',
                    'address': '202 Linking Road, Bandra West, Mumbai, Maharashtra 400050',
                    'phone': '+91-22-23456789',
                    'email': 'bandra@1mg.com',
                    'timings': '8:00 AM - 11:00 PM',
                    'services': ['Home Delivery', 'Online Orders', 'Lab Tests', 'Doctor Consultation'],
                    'rating': 4.4,
                    'total_reviews': 1890,
                    'delivery_available': True,
                    'accepts_insurance': True,
                    'parking_available': False,
                    'wheelchair_accessible': True,
                    'stock_status': 'Well Stocked',
                    'average_wait_time': '12 mins',
                    'contact_person': 'Ms. Neha Desai',
                    'license_number': 'MH-MUM-2024-002',
                    'established_year': 2016
                }
            ],
            'delhi': [
                {
                    'name': 'Apollo Pharmacy',
                    'branch': 'Connaught Place',
                    'address': '303 Connaught Place, New Delhi, Delhi 110001',
                    'phone': '+91-11-12345678',
                    'email': 'cp@apollopharmacy.in',
                    'timings': '24/7',
                    'services': ['Home Delivery', 'Online Orders', 'Prescription Filling', 'Vaccinations'],
                    'rating': 4.6,
                    'total_reviews': 3120,
                    'delivery_available': True,
                    'accepts_insurance': True,
                    'parking_available': True,
                    'wheelchair_accessible': True,
                    'stock_status': 'Excellent Stock',
                    'average_wait_time': '7 mins',
                    'contact_person': 'Mr. Vikram Singh',
                    'license_number': 'DL-DEL-2024-001',
                    'established_year': 2005
                },
                {
                    'name': 'MedPlus',
                    'branch': 'Saket',
                    'address': '404 Saket District Centre, New Delhi, Delhi 110017',
                    'phone': '+91-11-23456789',
                    'email': 'saket@medplus.in',
                    'timings': '8:00 AM - 10:00 PM',
                    'services': ['Home Delivery', 'Health Products', 'Medical Equipment', 'Lab Tests'],
                    'rating': 4.5,
                    'total_reviews': 2450,
                    'delivery_available': True,
                    'accepts_insurance': True,
                    'parking_available': True,
                    'wheelchair_accessible': True,
                    'stock_status': 'Well Stocked',
                    'average_wait_time': '10 mins',
                    'contact_person': 'Dr. Amit Kumar',
                    'license_number': 'DL-DEL-2024-002',
                    'established_year': 2009
                }
            ],
            'hyderabad': [
                {
                    'name': 'Apollo Pharmacy',
                    'branch': 'Banjara Hills',
                    'address': '505 Road No. 12, Banjara Hills, Hyderabad, Telangana 500034',
                    'phone': '+91-40-12345678',
                    'email': 'banjarahills@apollopharmacy.in',
                    'timings': '24/7',
                    'services': ['Home Delivery', 'Online Orders', 'Prescription Filling', 'Health Checkups'],
                    'rating': 4.6,
                    'total_reviews': 1890,
                    'delivery_available': True,
                    'accepts_insurance': True,
                    'parking_available': True,
                    'wheelchair_accessible': True,
                    'stock_status': 'Well Stocked',
                    'average_wait_time': '8 mins',
                    'contact_person': 'Mr. Ramesh Reddy',
                    'license_number': 'TS-HYD-2024-001',
                    'established_year': 2011
                }
            ],
            'chennai': [
                {
                    'name': 'Apollo Pharmacy',
                    'branch': 'T Nagar',
                    'address': '606 Usman Road, T Nagar, Chennai, Tamil Nadu 600017',
                    'phone': '+91-44-12345678',
                    'email': 'tnagar@apollopharmacy.in',
                    'timings': '24/7',
                    'services': ['Home Delivery', 'Online Orders', 'Prescription Filling', 'Medical Supplies'],
                    'rating': 4.5,
                    'total_reviews': 2100,
                    'delivery_available': True,
                    'accepts_insurance': True,
                    'parking_available': False,
                    'wheelchair_accessible': True,
                    'stock_status': 'Excellent Stock',
                    'average_wait_time': '6 mins',
                    'contact_person': 'Mr. Subramaniam',
                    'license_number': 'TN-CHE-2024-001',
                    'established_year': 2007
                }
            ]
        }
        
        return cities
    
    def search_pharmacies_by_city(self, city: str, drug_name: str = '') -> Dict:
        """
        Search pharmacies in a city with detailed information
        Returns comprehensive pharmacy details
        """
        city_lower = city.lower().strip()
        
        # Get pharmacies for the city
        pharmacies = self.pharmacy_database.get(city_lower, [])
        
        if not pharmacies:
            # Generate sample data for unknown cities
            pharmacies = self._generate_sample_pharmacies(city)
        
        # Add drug availability if drug name provided
        if drug_name:
            for pharmacy in pharmacies:
                pharmacy['drug_available'] = random.choice([True, True, True, False])  # 75% availability
                if pharmacy['drug_available']:
                    pharmacy['drug_price'] = f"₹{random.randint(50, 500)}"
                    pharmacy['drug_stock_quantity'] = random.randint(10, 200)
                else:
                    pharmacy['expected_restock_date'] = '2-3 days'
        
        return {
            'city': str(city),
            'total_pharmacies': int(len(pharmacies)),
            'pharmacies': pharmacies,
            'search_drug': str(drug_name) if drug_name else None
        }
    
    def _generate_sample_pharmacies(self, city: str) -> List[Dict]:
        """Generate sample pharmacy data for cities not in database"""
        pharmacy_chains = ['Apollo Pharmacy', 'MedPlus', 'Wellness Forever', '1mg', 'PharmEasy Store']
        
        pharmacies = []
        for i in range(3):
            pharmacy = {
                'name': str(pharmacy_chains[i % len(pharmacy_chains)]),
                'branch': f'{city} Central',
                'address': f'{100+i*100} Main Road, {city}',
                'phone': f'+91-{random.randint(1000000000, 9999999999)}',
                'email': f'{city.lower()}@{pharmacy_chains[i].lower().replace(" ", "")}.com',
                'timings': '24/7' if i == 0 else '8:00 AM - 10:00 PM',
                'services': ['Home Delivery', 'Online Orders', 'Prescription Filling'],
                'rating': float(round(4.0 + random.random() * 0.7, 1)),
                'total_reviews': int(random.randint(100, 2000)),
                'delivery_available': bool(True),
                'accepts_insurance': bool(i < 2),
                'parking_available': bool(i % 2 == 0),
                'wheelchair_accessible': bool(True),
                'stock_status': str(random.choice(['Excellent Stock', 'Well Stocked', 'Moderate Stock'])),
                'average_wait_time': f'{random.randint(5, 20)} mins',
                'contact_person': f'Pharmacy Manager',
                'license_number': f'IN-{city[:3].upper()}-2024-{str(i+1).zfill(3)}',
                'established_year': int(random.randint(2005, 2020))
            }
            pharmacies.append(pharmacy)
        
        return pharmacies
    
    def get_pharmacy_details(self, pharmacy_id: str, city: str) -> Dict:
        """Get detailed information about a specific pharmacy"""
        city_lower = city.lower().strip()
        pharmacies = self.pharmacy_database.get(city_lower, [])
        
        if pharmacies:
            # Return first pharmacy as example
            return pharmacies[0]
        
        return self._generate_sample_pharmacies(city)[0]

