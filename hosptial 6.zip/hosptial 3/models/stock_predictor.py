"""
AI-Powered Stock Prediction Model
Uses LSTM and Time Series Analysis for real-time stock forecasting
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional
from datetime import datetime, timedelta
import pickle
import os

# Try to import TensorFlow/Keras
HAS_TENSORFLOW = False
try:
    import tensorflow as tf
    # Test if TensorFlow is actually functional
    try:
        _ = tf.__version__
        from tensorflow.keras.models import Sequential
        from tensorflow.keras.layers import LSTM, Dense, Dropout, Bidirectional
        from tensorflow.keras.optimizers import Adam
        HAS_TENSORFLOW = True
    except (AttributeError, ImportError):
        HAS_TENSORFLOW = False
except (ImportError, AttributeError):
    HAS_TENSORFLOW = False

# Only print warning if running as main or in debug mode
if not HAS_TENSORFLOW and __name__ != '__main__':
    import sys
    if hasattr(sys, 'ps1'):  # Only in interactive mode
        pass  # Suppress warning in production


class StockPredictor:
    """
    AI-powered stock prediction using LSTM neural networks
    Predicts stock availability, demand, and restocking needs
    """
    
    def __init__(self, model_path='models/saved/stock_predictor.h5'):
        self.model_path = model_path
        self.model = None
        self.sequence_length = 7  # Days of history to use
        self.load_or_create_model()
    
    def load_or_create_model(self):
        """Load existing model or create new one"""
        if not HAS_TENSORFLOW:
            self.model = 'simple'
            return
        
        if os.path.exists(self.model_path):
            try:
                self.model = tf.keras.models.load_model(self.model_path)
            except:
                self.model = self._create_model()
        else:
            self.model = self._create_model()
    
    def _create_model(self):
        """Create LSTM model for stock prediction"""
        if not HAS_TENSORFLOW:
            return 'simple'
        
        model = Sequential([
            Bidirectional(LSTM(50, return_sequences=True), input_shape=(self.sequence_length, 1)),
            Dropout(0.2),
            LSTM(50, return_sequences=False),
            Dropout(0.2),
            Dense(25),
            Dense(1)
        ])
        
        model.compile(optimizer=Adam(learning_rate=0.001), loss='mse', metrics=['mae'])
        
        # Train on synthetic data
        X_train, y_train = self._generate_training_data()
        model.fit(X_train, y_train, epochs=20, batch_size=32, verbose=0)
        
        os.makedirs(os.path.dirname(self.model_path), exist_ok=True)
        model.save(self.model_path)
        
        return model
    
    def _generate_training_data(self):
        """Generate synthetic training data"""
        np.random.seed(42)
        n_samples = 200
        
        # Generate time series data
        X = []
        y = []
        
        for _ in range(n_samples):
            # Generate 7 days of stock history
            history = np.random.randint(0, 100, self.sequence_length).reshape(self.sequence_length, 1)
            # Next day prediction (with some trend)
            next_day = max(0, int(history[-1, 0] + np.random.normal(0, 10)))
            X.append(history)
            y.append(next_day)
        
        return np.array(X), np.array(y)
    
    def predict_stock(self, drug_id: str, history: List[Dict], days_ahead: int = 7) -> Dict:
        """
        Predict stock availability for next N days
        history: List of {'date': 'YYYY-MM-DD', 'stock': int}
        """
        if not history or len(history) < self.sequence_length:
            return self._simple_prediction(history, days_ahead)
        
        if not HAS_TENSORFLOW or self.model == 'simple':
            return self._simple_prediction(history, days_ahead)
        
        try:
            # Prepare data
            stock_values = [h['stock'] for h in history[-self.sequence_length:]]
            X = np.array(stock_values).reshape(1, self.sequence_length, 1)
            
            # Predict
            predictions = []
            current_input = X.copy()
            
            for _ in range(days_ahead):
                pred = self.model.predict(current_input, verbose=0)[0, 0]
                predictions.append(max(0, int(pred)))
                # Update input for next prediction
                new_input = np.append(current_input[0, 1:], [[pred]], axis=0)
                current_input = new_input.reshape(1, self.sequence_length, 1)
            
            # Calculate confidence
            recent_trend = np.mean(stock_values[-3:]) - np.mean(stock_values[:3])
            confidence = min(0.95, 0.7 + abs(recent_trend) / 100)
            
            return {
                'predictions': predictions,
                'confidence': float(confidence),
                'trend': 'increasing' if recent_trend > 0 else 'decreasing',
                'days_ahead': days_ahead,
                'model_type': 'LSTM'
            }
        except Exception as e:
            return self._simple_prediction(history, days_ahead)
    
    def _simple_prediction(self, history: List[Dict], days_ahead: int) -> Dict:
        """Simple prediction without ML"""
        if not history:
            return {
                'predictions': [50] * days_ahead,
                'confidence': 0.5,
                'trend': 'stable',
                'days_ahead': days_ahead,
                'model_type': 'simple'
            }
        
        recent_stocks = [h['stock'] for h in history[-7:]]
        avg_stock = np.mean(recent_stocks)
        trend = (recent_stocks[-1] - recent_stocks[0]) / len(recent_stocks) if len(recent_stocks) > 1 else 0
        
        predictions = []
        current = recent_stocks[-1] if recent_stocks else 50
        
        for i in range(days_ahead):
            current = max(0, int(current + trend))
            predictions.append(current)
        
        return {
            'predictions': predictions,
            'confidence': 0.7,
            'trend': 'increasing' if trend > 0 else 'decreasing' if trend < 0 else 'stable',
            'days_ahead': days_ahead,
            'model_type': 'simple'
        }
    
    def predict_demand(self, drug_id: str, location: str, historical_data: List[Dict]) -> Dict:
        """Predict demand for a drug"""
        if not historical_data:
            return {'predicted_demand': 10, 'confidence': 0.5}
        
        # Analyze historical patterns
        demands = [d.get('demand', 0) for d in historical_data if 'demand' in d]
        if demands:
            avg_demand = np.mean(demands)
            std_demand = np.std(demands)
            predicted = max(0, int(avg_demand + 0.5 * std_demand))
        else:
            predicted = 10
        
        return {
            'predicted_demand': predicted,
            'confidence': 0.75,
            'based_on_days': len(historical_data)
        }
    
    def recommend_restock(self, current_stock: int, predicted_demand: int, lead_time_days: int = 3) -> Dict:
        """Recommend restocking based on AI predictions"""
        days_until_out = current_stock / predicted_demand if predicted_demand > 0 else 999
        
        if days_until_out <= lead_time_days:
            urgency = 'critical'
            recommendation = 'Restock immediately'
        elif days_until_out <= lead_time_days * 2:
            urgency = 'high'
            recommendation = 'Restock soon'
        elif days_until_out <= lead_time_days * 3:
            urgency = 'medium'
            recommendation = 'Plan restocking'
        else:
            urgency = 'low'
            recommendation = 'Stock adequate'
        
        suggested_quantity = max(predicted_demand * (lead_time_days + 7), 50)
        
        return {
            'urgency': urgency,
            'recommendation': recommendation,
            'days_until_out': int(days_until_out),
            'suggested_quantity': int(suggested_quantity),
            'current_stock': current_stock,
            'predicted_demand': predicted_demand
        }

