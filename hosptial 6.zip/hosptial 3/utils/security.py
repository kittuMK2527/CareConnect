"""
Security Manager
Handles authentication and authorization
"""

from functools import wraps
from flask import request, jsonify, session
import hashlib
import secrets


class SecurityManager:
    """
    Security and authentication manager
    """
    
    def __init__(self):
        self.secret_key = secrets.token_hex(32)
    
    def hash_password(self, password: str) -> str:
        """Hash password using SHA-256"""
        return hashlib.sha256(password.encode()).hexdigest()
    
    def verify_password(self, password: str, hashed: str) -> bool:
        """Verify password against hash"""
        return self.hash_password(password) == hashed
    
    def generate_token(self) -> str:
        """Generate secure token"""
        return secrets.token_urlsafe(32)
    
    def require_auth(self, f):
        """Decorator for requiring authentication"""
        @wraps(f)
        def decorated_function(*args, **kwargs):
            token = request.headers.get('Authorization')
            if not token or not self.verify_token(token):
                return jsonify({'error': 'Unauthorized'}), 401
            return f(*args, **kwargs)
        return decorated_function
    
    def verify_token(self, token: str) -> bool:
        """Verify authentication token"""
        # In production, implement proper token verification
        return True  # Simplified for demo

