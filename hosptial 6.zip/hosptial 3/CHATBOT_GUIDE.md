# AI Chatbot Integration Guide

## ✅ What's Been Added

### 1. **Chatbot Service** (`services/chatbot.py`)
- AI-powered healthcare assistant
- Intent detection (9 different intents)
- Natural language processing
- Drug search and information
- Generic alternatives suggestions
- Prescription help
- Stock availability queries

### 2. **Backend API Endpoints**

#### POST `/api/chatbot`
Send messages to the chatbot
```json
{
  "message": "Hello",
  "user_id": "user123",
  "context": {"location": "Delhi"}
}
```

Response:
```json
{
  "success": true,
  "intent": "greeting",
  "response": {
    "text": "Hello! I'm your healthcare assistant...",
    "type": "text",
    "confidence": 1.0
  }
}
```

#### GET `/api/chatbot/history?user_id=user123&limit=10`
Get conversation history

### 3. **WebSocket Support**
- Real-time chatbot via Socket.IO
- Event: `chatbot_message` (send)
- Event: `chatbot_response` (receive)

### 4. **Frontend Chatbot UI**
- Floating chat widget (bottom right)
- Modern, responsive design
- Typing indicators
- Message history
- Auto-scroll

## 🎯 Chatbot Capabilities

The chatbot can handle:

1. **Greetings** - "Hello", "Hi", "Help"
2. **Drug Search** - "Search for paracetamol", "Find insulin"
3. **Drug Information** - "Tell me about metformin"
4. **Generic Alternatives** - "Generic for paracetamol", "Cheaper alternative"
5. **Stock Check** - "Is paracetamol in stock?", "Where can I buy insulin?"
6. **Prescription Help** - "How to verify prescription?", "Check prescription"
7. **Side Effects** - "Side effects of paracetamol"
8. **Dosage** - "How much to take?"
9. **Goodbye** - "Thank you", "Bye"

## 🚀 How to Use

### For Users:
1. Open http://localhost:5001
2. Click the chat icon (💬) in bottom right
3. Type your question
4. Get instant AI-powered responses

### Example Queries:
- "Hello"
- "Search for paracetamol"
- "Generic alternative for insulin"
- "Tell me about metformin"
- "Is paracetamol available in Delhi?"

## 🔧 Technical Details

### Intent Detection
Uses regex patterns to detect user intent:
- Pattern matching for common phrases
- Confidence scoring
- Fallback to general responses

### Drug Name Extraction
- Capitalized word detection
- Common drug keyword matching
- Fuzzy matching with database

### Response Generation
- Context-aware responses
- Structured data for special responses
- Confidence scoring

## 📊 Model Integration

The chatbot integrates with:
- ✅ Drug Matcher (fuzzy drug search)
- ✅ Generic Suggester (Jan Aushadhi alternatives)
- ✅ Database Manager (stock, pharmacy data)
- ✅ Fraud Detector (prescription verification)
- ✅ Prescription Validator (validation)

## 🎨 UI Features

- **Floating Button**: Always accessible
- **Smooth Animations**: Fade in/out
- **Typing Indicator**: Shows when bot is thinking
- **Message Bubbles**: User (right) and Bot (left)
- **Auto-scroll**: Always shows latest message
- **Responsive**: Works on mobile and desktop

## 🔒 Security

- User ID tracking (optional)
- Context-aware responses
- Input validation
- Error handling

## 📝 Future Enhancements

Possible additions:
- Voice input/output
- Multi-language support
- Sentiment analysis
- Conversation memory
- Integration with external APIs
- Machine learning for better intent detection

---

**Status**: ✅ Fully Integrated and Working
**Version**: 1.0.0

