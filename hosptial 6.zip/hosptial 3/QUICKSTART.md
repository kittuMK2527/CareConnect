# Quick Start Guide

## 🚀 Get Started in 5 Minutes

### Step 1: Install Dependencies

```bash
# Install Python packages
pip install -r requirements.txt

# Install Tesseract OCR (choose your OS)

# macOS
brew install tesseract

# Ubuntu/Debian
sudo apt-get install tesseract-ocr

# Windows
# Download from: https://github.com/UB-Mannheim/tesseract/wiki
```

### Step 2: Setup Project

```bash
# Run setup script
python setup.py
```

### Step 3: Test System (Optional)

```bash
# Verify all components work
python test_system.py
```

### Step 4: Run Application

```bash
# Start Flask server
python app.py
```

### Step 5: Open Browser

Navigate to: **http://localhost:5000**

---

## 📸 How to Use

1. **Upload Prescription**
   - Drag & drop or click to select prescription image
   - Enter Patient ID (optional)
   - Enter Location (e.g., "Delhi")

2. **Click "Process Prescription"**
   - System will:
     - Extract text using OCR
     - Match drugs with database
     - Detect fraud using ML models
     - Check stock availability
     - Suggest generic alternatives

3. **View Results**
   - Fraud detection score and reasons
   - Extracted drugs
   - Stock availability in nearby pharmacies
   - Generic alternatives with cost savings

---

## 🔧 Configuration

### MongoDB (Optional)

If you want to use MongoDB:

1. Install MongoDB: https://www.mongodb.com/try/download/community
2. Set environment variable:
   ```bash
   export MONGODB_URI="mongodb://localhost:27017/"
   ```

**Note**: System works without MongoDB (uses in-memory storage)

### Environment Variables

Create `.env` file (optional):

```
MONGODB_URI=mongodb://localhost:27017/
SECRET_KEY=your-secret-key-here
TESSERACT_CMD=/usr/bin/tesseract
```

---

## 🐛 Troubleshooting

### Tesseract Not Found

**Error**: `TesseractNotFoundError`

**Solution**: 
- Install Tesseract (see Step 1)
- Or set path in code:
  ```python
  pytesseract.pytesseract.tesseract_cmd = '/path/to/tesseract'
  ```

### MongoDB Connection Error

**Error**: `MongoDB connection error`

**Solution**: 
- System will work with in-memory storage
- Or install MongoDB and set MONGODB_URI

### Import Errors

**Error**: `ModuleNotFoundError`

**Solution**:
```bash
pip install -r requirements.txt
```

### Port Already in Use

**Error**: `Address already in use`

**Solution**: Change port in `app.py`:
```python
socketio.run(app, host='0.0.0.0', port=5001, debug=True)
```

---

## 📚 Next Steps

1. **Add More Drugs**: Edit `data/drug_database.json`
2. **Add Pharmacies**: Database will auto-create sample data
3. **Customize Models**: Modify `models/fraud_detector.py`
4. **Add Features**: Extend API endpoints in `app.py`

---

## 💡 Tips

- **Test with Sample Images**: Use clear, well-lit prescription photos
- **Start Small**: Test with one prescription first
- **Check Logs**: Look at console output for debugging
- **MongoDB Optional**: System works fine without it for testing

---

## 🆘 Need Help?

1. Check `README.md` for detailed documentation
2. Run `python test_system.py` to diagnose issues
3. Check console logs for error messages

---

**Happy Coding! 🎉**

