"""
Drug Matching Service with Fuzzy String Matching
Uses Levenshtein Distance for OCR error correction
"""

from Levenshtein import distance as levenshtein_distance
from typing import Dict, List, Optional
import json
import os


class DrugMatcher:
    """
    Matches extracted drug names with database using fuzzy matching
    """
    
    def __init__(self, drug_db_path='data/drug_database.json'):
        self.drug_db_path = drug_db_path
        self.drug_database = self._load_drug_database()
        self.confidence_threshold = 0.7  # 70% similarity threshold
    
    def _load_drug_database(self) -> List[Dict]:
        """Load drug database"""
        if os.path.exists(self.drug_db_path):
            with open(self.drug_db_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        else:
            # Return default database
            return self._get_default_drugs()
    
    def _get_default_drugs(self) -> List[Dict]:
        """Get default drug database with common Indian medicines"""
        return [
            {
                'drug_id': 'D001',
                'name': 'Paracetamol',
                'brand_names': ['Crocin', 'Calpol', 'Dolo'],
                'category': 'Analgesic',
                'schedule': 'H',
                'is_generic': True
            },
            {
                'drug_id': 'D002',
                'name': 'Amoxicillin',
                'brand_names': ['Amoxil', 'Mox', 'Amoxycillin'],
                'category': 'Antibiotic',
                'schedule': 'H',
                'is_generic': True
            },
            {
                'drug_id': 'D003',
                'name': 'Metformin',
                'brand_names': ['Glycomet', 'Metformin'],
                'category': 'Antidiabetic',
                'schedule': 'H',
                'is_generic': True
            },
            {
                'drug_id': 'D004',
                'name': 'Insulin',
                'brand_names': ['Humalog', 'Lantus', 'Novolog'],
                'category': 'Antidiabetic',
                'schedule': 'H',
                'is_generic': False
            },
            {
                'drug_id': 'D005',
                'name': 'Morphine',
                'brand_names': ['Morphine'],
                'category': 'Narcotic',
                'schedule': 'X',
                'is_generic': False
            },
            {
                'drug_id': 'D006',
                'name': 'Omeprazole',
                'brand_names': ['Omez', 'Omeprazole'],
                'category': 'Antacid',
                'schedule': 'H',
                'is_generic': True
            },
            {
                'drug_id': 'D007',
                'name': 'Atorvastatin',
                'brand_names': ['Atorva', 'Lipitor'],
                'category': 'Cardiovascular',
                'schedule': 'H',
                'is_generic': True
            },
            {
                'drug_id': 'D008',
                'name': 'Amlodipine',
                'brand_names': ['Amlodipine', 'Amlo'],
                'category': 'Cardiovascular',
                'schedule': 'H',
                'is_generic': True
            }
        ]
    
    def match_drug(self, extracted_name: str) -> Optional[Dict]:
        """
        Match extracted drug name with database using fuzzy matching
        Returns: matched drug info or None
        """
        if not extracted_name or len(extracted_name.strip()) < 2:
            return None
        
        extracted_name = extracted_name.strip().lower()
        best_match = None
        best_score = 0.0
        
        for drug in self.drug_database:
            # Check generic name
            generic_name = drug['name'].lower()
            score = self._calculate_similarity(extracted_name, generic_name)
            
            if score > best_score:
                best_score = score
                best_match = drug.copy()
            
            # Check brand names
            for brand in drug.get('brand_names', []):
                brand_lower = brand.lower()
                score = self._calculate_similarity(extracted_name, brand_lower)
                
                if score > best_score:
                    best_score = score
                    best_match = drug.copy()
                    best_match['matched_name'] = brand
        
        # Return match if confidence is above threshold
        if best_match and best_score >= self.confidence_threshold:
            best_match['match_confidence'] = best_score
            best_match['matched_name'] = best_match.get('matched_name', best_match['name'])
            return best_match
        
        return None
    
    def _calculate_similarity(self, str1: str, str2: str) -> float:
        """
        Calculate similarity using Levenshtein Distance
        Returns: similarity score (0-1)
        """
        if not str1 or not str2:
            return 0.0
        
        # Calculate Levenshtein distance
        max_len = max(len(str1), len(str2))
        if max_len == 0:
            return 1.0
        
        distance = levenshtein_distance(str1, str2)
        similarity = 1.0 - (distance / max_len)
        
        # Bonus for substring matches
        if str1 in str2 or str2 in str1:
            similarity = min(similarity + 0.2, 1.0)
        
        return similarity
    
    def search_drugs(self, query: str, limit: int = 10) -> List[Dict]:
        """Search drugs in database"""
        if not query:
            return []
        
        query_lower = query.lower()
        results = []
        
        for drug in self.drug_database:
            score = 0.0
            
            # Check generic name
            if query_lower in drug['name'].lower():
                score = 0.8
            else:
                score = self._calculate_similarity(query_lower, drug['name'].lower())
            
            # Check brand names
            for brand in drug.get('brand_names', []):
                if query_lower in brand.lower():
                    score = max(score, 0.9)
                else:
                    score = max(score, self._calculate_similarity(query_lower, brand.lower()))
            
            if score > 0.3:  # Lower threshold for search
                drug_copy = drug.copy()
                drug_copy['relevance_score'] = score
                results.append(drug_copy)
        
        # Sort by relevance
        results.sort(key=lambda x: x['relevance_score'], reverse=True)
        
        return results[:limit]

