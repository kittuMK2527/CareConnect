"""
Configuration file for the application
"""

import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    """Application configuration"""
    
    # Flask
    SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
    
    # MongoDB
    MONGODB_URI = os.environ.get('MONGODB_URI', 'mongodb://localhost:27017/')
    DB_NAME = 'hospital_drug_system'
    
    # File Upload
    UPLOAD_FOLDER = 'uploads/prescriptions'
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'pdf'}
    
    # OCR
    TESSERACT_CMD = os.environ.get('TESSERACT_CMD', None)  # Auto-detect if None
    
    # ML Models
    FRAUD_MODEL_PATH = 'models/saved/fraud_model.pkl'
    VALIDATION_MODEL_PATH = 'models/saved/validation_model.h5'
    
    # Encryption
    ENCRYPTION_KEY_PATH = 'data/encryption_key.key'
    
    # Drug Database
    DRUG_DB_PATH = 'data/drug_database.json'
    
    # Fraud Detection Thresholds
    FRAUD_THRESHOLD_HIGH = 0.7
    FRAUD_THRESHOLD_MEDIUM = 0.5
    
    # OCR Confidence Threshold
    OCR_CONFIDENCE_THRESHOLD = 70
    
    # Stock Search
    DEFAULT_SEARCH_RADIUS_KM = 10

