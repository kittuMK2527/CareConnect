"""
Test script to verify system components
Run this to test individual components
"""

import sys
import os

def test_imports():
    """Test if all imports work"""
    print("Testing imports...")
    try:
        from models.fraud_detector import FraudDetector
        from models.prescription_validator import PrescriptionValidator
        from services.ocr_service import OCRService
        from services.drug_matcher import DrugMatcher
        from services.stock_manager import StockManager
        from services.generic_suggester import GenericSuggester
        from database.db_manager import DatabaseManager
        from utils.security import SecurityManager
        from utils.encryption import EncryptionManager
        print("✓ All imports successful")
        return True
    except Exception as e:
        print(f"✗ Import error: {e}")
        return False

def test_fraud_detector():
    """Test fraud detection"""
    print("\nTesting Fraud Detector...")
    try:
        from models.fraud_detector import FraudDetector
        detector = FraudDetector()
        
        test_prescription = {
            'patient_id': 'P001',
            'doctor_name': 'Dr. Test',
            'hospital_id': 'HOSP001',
            'date': '2024-01-15',
            'drugs': [{'name': 'Paracetamol', 'drug_id': 'D001'}],
            'ocr_confidence': 85,
            'location': 'Delhi'
        }
        
        score, reasons = detector.detect_fraud(test_prescription)
        print(f"✓ Fraud detection working - Score: {score:.2f}")
        print(f"  Reasons: {len(reasons)} detected")
        return True
    except Exception as e:
        print(f"✗ Fraud detector error: {e}")
        return False

def test_drug_matcher():
    """Test drug matching"""
    print("\nTesting Drug Matcher...")
    try:
        from services.drug_matcher import DrugMatcher
        matcher = DrugMatcher()
        
        # Test fuzzy matching
        match = matcher.match_drug('Paracetamol')
        if match:
            print(f"✓ Drug matching working - Matched: {match['name']}")
        else:
            print("⚠ No match found (may need database)")
        
        # Test with OCR error
        match2 = matcher.match_drug('Para-cetmol')  # Common OCR error
        if match2:
            print(f"✓ Fuzzy matching working - Corrected: {match2['name']}")
        
        return True
    except Exception as e:
        print(f"✗ Drug matcher error: {e}")
        return False

def test_database():
    """Test database connection"""
    print("\nTesting Database...")
    try:
        from database.db_manager import DatabaseManager
        db = DatabaseManager()
        stats = db.get_dashboard_stats()
        print(f"✓ Database connection working")
        print(f"  Stats: {stats}")
        return True
    except Exception as e:
        print(f"⚠ Database test: {e}")
        print("  (System will work with in-memory storage)")
        return True  # Not critical

def test_encryption():
    """Test encryption"""
    print("\nTesting Encryption...")
    try:
        from utils.encryption import EncryptionManager
        enc_manager = EncryptionManager()
        print("✓ Encryption manager initialized")
        return True
    except Exception as e:
        print(f"✗ Encryption error: {e}")
        return False

def main():
    """Run all tests"""
    print("=" * 60)
    print("🧪 System Component Tests")
    print("=" * 60)
    
    tests = [
        ("Imports", test_imports),
        ("Fraud Detector", test_fraud_detector),
        ("Drug Matcher", test_drug_matcher),
        ("Database", test_database),
        ("Encryption", test_encryption)
    ]
    
    results = []
    for name, test_func in tests:
        try:
            result = test_func()
            results.append((name, result))
        except Exception as e:
            print(f"✗ {name} failed with exception: {e}")
            results.append((name, False))
    
    print("\n" + "=" * 60)
    print("📊 Test Results:")
    print("=" * 60)
    
    for name, result in results:
        status = "✓ PASS" if result else "✗ FAIL"
        print(f"{status} - {name}")
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    print(f"\nTotal: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n✅ All tests passed! System is ready.")
    else:
        print("\n⚠ Some tests failed. Check errors above.")

if __name__ == '__main__':
    main()

