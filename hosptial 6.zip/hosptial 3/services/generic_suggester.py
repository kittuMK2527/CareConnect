"""
Generic Drug Suggester
Suggests Jan Aushadhi (affordable generic) alternatives
"""

from typing import Dict, List
from database.db_manager import DatabaseManager


class GenericSuggester:
    """
    Suggests generic alternatives for branded drugs
    Helps users save 50-80% on costs
    """
    
    def __init__(self, db_manager: DatabaseManager):
        self.db_manager = db_manager
        self.jan_aushadhi_drugs = self._load_jan_aushadhi_drugs()
    
    def _load_jan_aushadhi_drugs(self) -> Dict:
        """Load Jan Aushadhi generic drug database"""
        return {
            'D001': [  # Paracetamol
                {'name': 'Paracetamol 500mg', 'price': 2.50, 'savings': '75%'},
                {'name': 'Paracetamol 650mg', 'price': 3.00, 'savings': '70%'}
            ],
            'D002': [  # Amoxicillin
                {'name': 'Amoxicillin 250mg', 'price': 15.00, 'savings': '60%'},
                {'name': 'Amoxicillin 500mg', 'price': 25.00, 'savings': '65%'}
            ],
            'D003': [  # Metformin
                {'name': 'Metformin 500mg', 'price': 8.00, 'savings': '80%'},
                {'name': 'Metformin 1000mg', 'price': 12.00, 'savings': '75%'}
            ],
            'D004': [  # Insulin (no generic, suggest alternatives)
                {'name': 'Human Insulin (Generic)', 'price': 200.00, 'savings': '50%'}
            ],
            'D006': [  # Omeprazole
                {'name': 'Omeprazole 20mg', 'price': 5.00, 'savings': '70%'},
                {'name': 'Omeprazole 40mg', 'price': 8.00, 'savings': '65%'}
            ],
            'D007': [  # Atorvastatin
                {'name': 'Atorvastatin 10mg', 'price': 12.00, 'savings': '60%'},
                {'name': 'Atorvastatin 20mg', 'price': 18.00, 'savings': '55%'}
            ],
            'D008': [  # Amlodipine
                {'name': 'Amlodipine 5mg', 'price': 6.00, 'savings': '70%'},
                {'name': 'Amlodipine 10mg', 'price': 10.00, 'savings': '65%'}
            ]
        }
    
    def suggest_generics(self, drug_id: str, limit: int = 3) -> List[Dict]:
        """
        Suggest generic alternatives for a drug
        Returns: list of generic alternatives with prices
        """
        alternatives = self.jan_aushadhi_drugs.get(drug_id, [])
        
        # Add additional info
        for alt in alternatives:
            alt['source'] = 'Jan Aushadhi'
            alt['available'] = True  # In production, check actual availability
        
        return alternatives[:limit]
    
    def calculate_savings(self, original_drug: Dict, generic_alternatives: List[Dict]) -> Dict:
        """Calculate potential savings"""
        if not generic_alternatives:
            return {'savings_percentage': 0, 'savings_amount': 0}
        
        # In production, get actual prices from database
        original_price = original_drug.get('price', 100)  # Default
        best_generic = min(generic_alternatives, key=lambda x: x.get('price', 999))
        generic_price = best_generic.get('price', 0)
        
        savings_amount = original_price - generic_price
        savings_percentage = (savings_amount / original_price * 100) if original_price > 0 else 0
        
        return {
            'savings_percentage': round(savings_percentage, 2),
            'savings_amount': round(savings_amount, 2),
            'best_alternative': best_generic
        }

