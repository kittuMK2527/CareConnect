"""
Database Manager for MongoDB
Handles all database operations
"""

from pymongo import MongoClient
from typing import Dict, List, Optional
from datetime import datetime, timedelta
import json
import os


class DatabaseManager:
    """
    MongoDB database manager
    Handles prescriptions, pharmacies, drugs, and stock
    """
    
    def __init__(self, connection_string: str = None):
        # Use MongoDB connection string or default to local
        self.connection_string = connection_string or os.environ.get(
            'MONGODB_URI', 'mongodb://localhost:27017/'
        )
        self.db_name = 'hospital_drug_system'
        self.client = None
        self.db = None
        self._connect()
    
    def _connect(self):
        """Connect to MongoDB"""
        try:
            self.client = MongoClient(self.connection_string)
            self.db = self.client[self.db_name]
            # Test connection
            self.client.admin.command('ping')
        except Exception as e:
            print(f"MongoDB connection error: {e}")
            print("Using in-memory storage (data will not persist)")
            self.db = None
    
    def initialize_database(self):
        """Initialize database with sample data"""
        if not self.db:
            return
        
        # Create collections
        collections = ['prescriptions', 'pharmacies', 'drugs', 'stock', 'doctors', 'users']
        for coll_name in collections:
            if coll_name not in self.db.list_collection_names():
                self.db.create_collection(coll_name)
        
        # Insert sample pharmacies
        self._insert_sample_pharmacies()
        
        # Insert sample doctors
        self._insert_sample_doctors()
    
    def _insert_sample_pharmacies(self):
        """Insert sample pharmacy data"""
        if not self.db:
            return
        
        pharmacies = [
            {
                'pharmacy_id': 'P001',
                'name': 'Apollo Pharmacy',
                'location': 'Delhi',
                'address': '123 Main Street, Delhi',
                'latitude': 28.6139,
                'longitude': 77.2090,
                'phone': '+91-1234567890'
            },
            {
                'pharmacy_id': 'P002',
                'name': 'MedPlus Pharmacy',
                'location': 'Mumbai',
                'address': '456 Park Avenue, Mumbai',
                'latitude': 19.0760,
                'longitude': 72.8777,
                'phone': '+91-9876543210'
            },
            {
                'pharmacy_id': 'P003',
                'name': 'Wellness Forever',
                'location': 'Bangalore',
                'address': '789 Tech Park, Bangalore',
                'latitude': 12.9716,
                'longitude': 77.5946,
                'phone': '+91-1122334455'
            }
        ]
        
        collection = self.db['pharmacies']
        for pharmacy in pharmacies:
            collection.update_one(
                {'pharmacy_id': pharmacy['pharmacy_id']},
                {'$set': pharmacy},
                upsert=True
            )
        
        # Insert sample stock
        stock_data = [
            {'pharmacy_id': 'P001', 'drug_id': 'D001', 'quantity': 100, 'last_updated': datetime.now()},
            {'pharmacy_id': 'P001', 'drug_id': 'D002', 'quantity': 50, 'last_updated': datetime.now()},
            {'pharmacy_id': 'P002', 'drug_id': 'D001', 'quantity': 75, 'last_updated': datetime.now()},
            {'pharmacy_id': 'P002', 'drug_id': 'D003', 'quantity': 30, 'last_updated': datetime.now()},
            {'pharmacy_id': 'P003', 'drug_id': 'D004', 'quantity': 20, 'last_updated': datetime.now()},
        ]
        
        stock_collection = self.db['stock']
        for stock in stock_data:
            stock_collection.update_one(
                {'pharmacy_id': stock['pharmacy_id'], 'drug_id': stock['drug_id']},
                {'$set': stock},
                upsert=True
            )
    
    def _insert_sample_doctors(self):
        """Insert sample doctor data"""
        if not self.db:
            return
        
        doctors = [
            {
                'doctor_id': 'DOC001',
                'name': 'Dr. Rajesh Kumar',
                'hospital_id': 'HOSP001',
                'hospital_name': 'AIIMS Delhi',
                'specialization': 'Cardiology',
                'registration_number': 'REG-12345'
            },
            {
                'doctor_id': 'DOC002',
                'name': 'Dr. Priya Sharma',
                'hospital_id': 'HOSP002',
                'hospital_name': 'Apollo Hospital',
                'specialization': 'General Medicine',
                'registration_number': 'REG-67890'
            }
        ]
        
        collection = self.db['doctors']
        for doctor in doctors:
            collection.update_one(
                {'doctor_id': doctor['doctor_id']},
                {'$set': doctor},
                upsert=True
            )
    
    def create_user(self, user_data: Dict) -> Optional[str]:
        """Create a new user"""
        if not self.db:
            # In-memory fallback
            return f"user_{datetime.now().timestamp()}"
        
        try:
            collection = self.db['users']
            result = collection.insert_one(user_data)
            return str(result.inserted_id)
        except Exception as e:
            print(f"Error creating user: {e}")
            return None
    
    def get_user_by_email(self, email: str) -> Optional[Dict]:
        """Get user by email"""
        if not self.db:
            return None
        
        try:
            collection = self.db['users']
            user = collection.find_one({'email': email.lower()})
            if user:
                user['_id'] = str(user['_id'])
            return user
        except Exception as e:
            print(f"Error getting user: {e}")
            return None
    
    def save_prescription(self, prescription_data: Dict) -> str:
        """Save prescription to database"""
        if not self.db:
            # Return mock ID if no database
            return f"PRES_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
        prescription_data['created_at'] = datetime.now()
        result = self.db['prescriptions'].insert_one(prescription_data)
        return str(result.inserted_id)
    
    def get_recent_prescriptions(self, limit: int = 10) -> List[Dict]:
        """Get recent prescriptions"""
        if not self.db:
            return []
        
        try:
            collection = self.db['prescriptions']
            prescriptions = list(collection.find().sort('timestamp', -1).limit(limit))
            for pres in prescriptions:
                pres['_id'] = str(pres['_id'])
            return prescriptions
        except Exception as e:
            print(f"Error getting recent prescriptions: {e}")
            return []
    
    def get_prescription(self, prescription_id: str) -> Optional[Dict]:
        """Get prescription by ID"""
        if not self.db:
            return None
        
        return self.db['prescriptions'].find_one({'_id': prescription_id})
    
    def get_pharmacies_with_stock(self, drug_id: str) -> List[Dict]:
        """Get pharmacies that have stock of a drug"""
        if not self.db:
            # Return mock data
            return [
                {
                    'pharmacy_id': 'P001',
                    'name': 'Apollo Pharmacy',
                    'location': 'Delhi',
                    'stock_quantity': 50,
                    'distance_km': 2.5
                }
            ]
        
        # Join stock and pharmacy collections
        pipeline = [
            {'$match': {'drug_id': drug_id, 'quantity': {'$gt': 0}}},
            {
                '$lookup': {
                    'from': 'pharmacies',
                    'localField': 'pharmacy_id',
                    'foreignField': 'pharmacy_id',
                    'as': 'pharmacy_info'
                }
            },
            {'$unwind': '$pharmacy_info'},
            {
                '$project': {
                    'pharmacy_id': 1,
                    'name': '$pharmacy_info.name',
                    'location': '$pharmacy_info.location',
                    'address': '$pharmacy_info.address',
                    'phone': '$pharmacy_info.phone',
                    'stock_quantity': '$quantity',
                    'latitude': '$pharmacy_info.latitude',
                    'longitude': '$pharmacy_info.longitude'
                }
            }
        ]
        
        results = list(self.db['stock'].aggregate(pipeline))
        return results
    
    def update_pharmacy_stock(self, pharmacy_id: str, drug_id: str, quantity: int):
        """Update pharmacy stock"""
        if not self.db:
            return
        
        self.db['stock'].update_one(
            {'pharmacy_id': pharmacy_id, 'drug_id': drug_id},
            {
                '$set': {
                    'quantity': quantity,
                    'last_updated': datetime.now()
                }
            },
            upsert=True
        )
    
    def get_stock_history(self, drug_id: str, days: int = 30) -> List[Dict]:
        """Get stock history for a drug"""
        if not self.db:
            return []
        
        from_date = datetime.now() - timedelta(days=days)
        return list(self.db['stock'].find({
            'drug_id': drug_id,
            'last_updated': {'$gte': from_date}
        }).sort('last_updated', -1))
    
    def get_dashboard_stats(self) -> Dict:
        """Get dashboard statistics"""
        if not self.db:
            return {
                'total_prescriptions': 0,
                'fraud_detected': 0,
                'total_pharmacies': 0,
                'total_drugs': 0
            }
        
        total_prescriptions = self.db['prescriptions'].count_documents({})
        fraud_detected = self.db['prescriptions'].count_documents({'is_fraud': True})
        total_pharmacies = self.db['pharmacies'].count_documents({})
        total_drugs = self.db['drugs'].count_documents({})
        
        return {
            'total_prescriptions': total_prescriptions,
            'fraud_detected': fraud_detected,
            'total_pharmacies': total_pharmacies,
            'total_drugs': total_drugs,
            'fraud_rate': round((fraud_detected / total_prescriptions * 100) if total_prescriptions > 0 else 0, 2)
        }

