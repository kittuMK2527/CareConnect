"""
Deep Learning Model for Prescription Validation
Uses TensorFlow/Keras for advanced pattern recognition
"""

import numpy as np
import pickle
import os
from typing import Dict, List
import json

# Try to import TensorFlow/Keras, with fallback
HAS_TENSORFLOW = False
try:
    import tensorflow as tf
    # Test if TensorFlow is actually functional
    try:
        _ = tf.__version__
        HAS_TENSORFLOW = True
        try:
            from tensorflow import keras
            from tensorflow.keras import layers, models, optimizers, utils
        except ImportError:
            try:
                import keras
                from keras import layers, models, optimizers, utils
            except ImportError:
                HAS_TENSORFLOW = False
    except (AttributeError, ImportError):
        HAS_TENSORFLOW = False
except (ImportError, AttributeError):
    HAS_TENSORFLOW = False

# Only print warning if running as main or in debug mode
if not HAS_TENSORFLOW and __name__ != '__main__':
    import sys
    if hasattr(sys, 'ps1'):  # Only in interactive mode
        pass  # Suppress warning in production


class PrescriptionValidator:
    """
    Deep learning model for prescription validation
    Uses CNN/RNN hybrid architecture for pattern recognition
    """
    
    def __init__(self, model_path='models/saved/validation_model.h5'):
        self.model_path = model_path
        self.model = None
        self.input_dim = 50  # Feature vector dimension
        self.load_or_create_model()
    
    def load_or_create_model(self):
        """Load existing model or create new one"""
        if not HAS_TENSORFLOW:
            self.model = 'simple'  # Use simple validation
            return
            
        if os.path.exists(self.model_path):
            try:
                self.model = models.load_model(self.model_path)
            except:
                self.model = self._create_model()
        else:
            self.model = self._create_model()
    
    def _create_model(self):
        """Create deep learning model architecture"""
        if not HAS_TENSORFLOW:
            return 'simple'
            
        model = keras.Sequential([
            # Input layer
            layers.Dense(128, activation='relu', input_shape=(self.input_dim,)),
            layers.BatchNormalization(),
            layers.Dropout(0.3),
            
            # Hidden layers
            layers.Dense(64, activation='relu'),
            layers.BatchNormalization(),
            layers.Dropout(0.3),
            
            layers.Dense(32, activation='relu'),
            layers.Dropout(0.2),
            
            # Output layer (3 classes: valid, suspicious, invalid)
            layers.Dense(3, activation='softmax')
        ])
        
        model.compile(
            optimizer=optimizers.Adam(learning_rate=0.001),
            loss='categorical_crossentropy',
            metrics=['accuracy']
        )
        
        # Train on synthetic data
        X_train, y_train = self._generate_training_data()
        model.fit(X_train, y_train, epochs=10, batch_size=32, verbose=0)
        
        # Save model
        os.makedirs(os.path.dirname(self.model_path), exist_ok=True)
        model.save(self.model_path)
        
        return model
    
    def _generate_training_data(self):
        """Generate synthetic training data"""
        np.random.seed(42)
        n_samples = 500
        
        # Generate feature vectors
        X = np.random.rand(n_samples, self.input_dim)
        
        # Generate labels (one-hot encoded)
        # 0: valid, 1: suspicious, 2: invalid
        y = np.random.randint(0, 3, n_samples)
        if HAS_TENSORFLOW:
            y_one_hot = utils.to_categorical(y, 3)
        else:
            # Simple one-hot encoding without keras
            y_one_hot = np.zeros((n_samples, 3))
            y_one_hot[np.arange(n_samples), y] = 1
        
        return X, y_one_hot
    
    def extract_features(self, prescription_data: Dict) -> np.ndarray:
        """Extract features for deep learning model"""
        features = []
        
        # Prescription metadata features
        has_doctor_name = 1.0 if prescription_data.get('doctor_name') else 0.0
        has_hospital_id = 1.0 if prescription_data.get('hospital_id') else 0.0
        has_date = 1.0 if prescription_data.get('date') else 0.0
        
        features.extend([has_doctor_name, has_hospital_id, has_date])
        
        # OCR confidence normalized
        ocr_conf = prescription_data.get('ocr_confidence', 0) / 100.0
        features.append(ocr_conf)
        
        # Drug count and types
        drugs = prescription_data.get('drugs', [])
        drug_count = len(drugs)
        features.append(min(drug_count / 10.0, 1.0))  # Normalize
        
        # Drug risk indicators
        schedule_drugs = sum(1 for d in drugs if 'schedule' in d.get('name', '').lower())
        features.append(min(schedule_drugs / 5.0, 1.0))
        
        # Text quality indicators (simulated)
        text_quality = ocr_conf * 0.8  # Assume good OCR = good text
        features.append(text_quality)
        
        # Pad to input_dim
        while len(features) < self.input_dim:
            features.append(0.0)
        
        return np.array(features[:self.input_dim]).reshape(1, -1)
    
    def validate(self, prescription_data: Dict) -> Dict:
        """
        Validate prescription using deep learning model
        Returns: validation result with score and status
        """
        # Extract features
        features = self.extract_features(prescription_data)
        
        # Use simple validation if TensorFlow not available
        if not HAS_TENSORFLOW or self.model == 'simple':
            return self._simple_validate(prescription_data)
        
        # Predict using deep learning model
        predictions = self.model.predict(features, verbose=0)[0]
        
        # Get class probabilities
        valid_prob = float(predictions[0])
        suspicious_prob = float(predictions[1])
        invalid_prob = float(predictions[2])
        
        # Determine status
        max_idx = np.argmax(predictions)
        statuses = ['valid', 'suspicious', 'invalid']
        status = statuses[max_idx]
        
        # Calculate overall score (weighted)
        score = valid_prob * 1.0 + suspicious_prob * 0.5 + invalid_prob * 0.0
        
        return {
            'score': float(score),
            'status': str(status),
            'probabilities': {
                'valid': float(valid_prob),
                'suspicious': float(suspicious_prob),
                'invalid': float(invalid_prob)
            },
            'confidence': float(max(predictions))
        }
    
    def _simple_validate(self, prescription_data: Dict) -> Dict:
        """Simple validation without TensorFlow"""
        # Simple rule-based validation
        score = 0.7  # Default moderate score
        
        # Increase score if has required fields
        if prescription_data.get('doctor_name'):
            score += 0.1
        if prescription_data.get('hospital_id'):
            score += 0.1
        if prescription_data.get('date'):
            score += 0.05
        
        # Decrease score if low OCR confidence
        ocr_conf = prescription_data.get('ocr_confidence', 0)
        if ocr_conf < 70:
            score -= 0.2
        
        score = max(0.0, min(1.0, score))
        
        if score >= 0.7:
            status = 'valid'
        elif score >= 0.5:
            status = 'suspicious'
        else:
            status = 'invalid'
        
        return {
            'score': float(score),
            'status': str(status),
            'probabilities': {
                'valid': float(score if score >= 0.7 else 0.3),
                'suspicious': float(0.3 if 0.5 <= score < 0.7 else 0.2),
                'invalid': float(1.0 - score if score < 0.5 else 0.2)
            },
            'confidence': float(score)
        }

