"""
Real-time Stock Tracking Service with AI
Uses WebSocket for live updates and AI for predictions
"""

from flask_socketio import emit
from typing import Dict, List, Optional
from datetime import datetime, timedelta
from models.stock_predictor import StockPredictor
import threading
import time


class RealtimeStockTracker:
    """
    Real-time stock tracking with AI predictions
    Monitors stock levels and sends updates via WebSocket
    """
    
    def __init__(self, db_manager, stock_manager, socketio):
        self.db_manager = db_manager
        self.stock_manager = stock_manager
        self.socketio = socketio
        self.stock_predictor = StockPredictor()
        self.subscribers = {}  # {drug_id: [socket_ids]}
        self.monitoring = False
        self.monitor_thread = None
    
    def subscribe(self, drug_id: str, socket_id: str):
        """Subscribe to stock updates for a drug"""
        if drug_id not in self.subscribers:
            self.subscribers[drug_id] = []
        if socket_id not in self.subscribers[drug_id]:
            self.subscribers[drug_id].append(socket_id)
        
        # Start monitoring if not already started
        if not self.monitoring:
            self.start_monitoring()
    
    def unsubscribe(self, drug_id: str, socket_id: str):
        """Unsubscribe from stock updates"""
        if drug_id in self.subscribers:
            if socket_id in self.subscribers[drug_id]:
                self.subscribers[drug_id].remove(socket_id)
            if not self.subscribers[drug_id]:
                del self.subscribers[drug_id]
    
    def start_monitoring(self):
        """Start background monitoring thread"""
        if self.monitoring:
            return
        
        self.monitoring = True
        self.monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.monitor_thread.start()
    
    def _monitor_loop(self):
        """Background monitoring loop"""
        while self.monitoring:
            try:
                for drug_id in list(self.subscribers.keys()):
                    self._check_and_update_stock(drug_id)
                time.sleep(5)  # Check every 5 seconds
            except Exception as e:
                print(f"Monitoring error: {e}")
                time.sleep(10)
    
    def _check_and_update_stock(self, drug_id: str):
        """Check stock and send updates"""
        try:
            # Get current stock
            pharmacies = self.db_manager.get_pharmacies_with_stock(drug_id)
            total_stock = sum(p.get('stock_quantity', 0) for p in pharmacies)
            
            # Get stock history for prediction
            history = self._get_stock_history(drug_id)
            
            # AI Prediction
            prediction = self.stock_predictor.predict_stock(drug_id, history, days_ahead=7)
            
            # Demand prediction
            demand_pred = self.stock_predictor.predict_demand(drug_id, '', history)
            
            # Restock recommendation
            restock_rec = self.stock_predictor.recommend_restock(
                total_stock,
                demand_pred['predicted_demand']
            )
            
            # Prepare update
            update = {
                'drug_id': drug_id,
                'timestamp': datetime.now().isoformat(),
                'current_stock': total_stock,
                'pharmacies_count': len(pharmacies),
                'prediction': prediction,
                'demand_prediction': demand_pred,
                'restock_recommendation': restock_rec,
                'status': 'in_stock' if total_stock > 0 else 'out_of_stock',
                'urgency': restock_rec['urgency']
            }
            
            # Send to all subscribers
            for socket_id in self.subscribers.get(drug_id, []):
                self.socketio.emit('stock_update', update, room=socket_id)
        
        except Exception as e:
            print(f"Stock check error for {drug_id}: {e}")
    
    def _get_stock_history(self, drug_id: str, days: int = 30) -> List[Dict]:
        """Get stock history for prediction"""
        try:
            history = self.db_manager.get_stock_history(drug_id, days)
            return [
                {
                    'date': h.get('last_updated', datetime.now()).strftime('%Y-%m-%d') if hasattr(h.get('last_updated'), 'strftime') else str(h.get('last_updated', '')),
                    'stock': h.get('quantity', 0)
                }
                for h in history
            ]
        except:
            # Generate synthetic history if not available
            return [
                {
                    'date': (datetime.now() - timedelta(days=i)).strftime('%Y-%m-%d'),
                    'stock': 50 + (i * 2)  # Sample data
                }
                for i in range(7, 0, -1)
            ]
    
    def get_realtime_status(self, drug_id: str, location: str = '') -> Dict:
        """Get real-time stock status with AI predictions"""
        # Get current stock
        stock_info = self.stock_manager.check_availability(drug_id, location, radius_km=10)
        
        # Get history
        history = self._get_stock_history(drug_id)
        
        # AI predictions
        prediction = self.stock_predictor.predict_stock(drug_id, history, days_ahead=7)
        demand_pred = self.stock_predictor.predict_demand(drug_id, location, history)
        restock_rec = self.stock_predictor.recommend_restock(
            stock_info.get('total_stock', 0),
            demand_pred['predicted_demand']
        )
        
        return {
            'current': stock_info,
            'prediction': prediction,
            'demand': demand_pred,
            'restock': restock_rec,
            'realtime': True,
            'timestamp': datetime.now().isoformat()
        }

