"""
AI-Powered Drug Availability & Prescription Fraud Detection System
Main Flask Application
"""

from flask import Flask, render_template, request, jsonify, session
from flask_cors import CORS
from flask_socketio import SocketIO, emit
import os
from datetime import datetime
import json
from werkzeug.utils import secure_filename
import base64

from models.fraud_detector import FraudDetector
from models.prescription_validator import PrescriptionValidator
from models.advanced_fraud_detector import AdvancedFraudDetector
from models.image_classifier import PrescriptionImageClassifier
from models.stock_predictor import StockPredictor
from models.safety_predictor import SafetyPredictor
from models.disease_detector import DiseaseDetector
from services.ocr_service import OCRService
from services.pharmacy_locator import PharmacyLocator
from services.drug_matcher import DrugMatcher
from services.stock_manager import StockManager
from services.generic_suggester import GenericSuggester
from services.chatbot import HealthcareChatbot
from services.advanced_chatbot import AdvancedChatbot
from services.realtime_stock_tracker import RealtimeStockTracker
from database.db_manager import DatabaseManager
from utils.security import SecurityManager
from utils.encryption import EncryptionManager
from werkzeug.security import generate_password_hash, check_password_hash
from utils.json_encoder import make_json_serializable
import numpy as np

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
app.config['UPLOAD_FOLDER'] = 'uploads/prescriptions'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

CORS(app)
# Try eventlet, fallback to threading if not available
try:
    socketio = SocketIO(app, cors_allowed_origins="*", async_mode='eventlet')
except:
    socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

# Initialize services
db_manager = DatabaseManager()
ocr_service = OCRService()
drug_matcher = DrugMatcher()
stock_manager = StockManager(db_manager)
generic_suggester = GenericSuggester(db_manager)
fraud_detector = FraudDetector()
advanced_fraud_detector = AdvancedFraudDetector()
prescription_validator = PrescriptionValidator()
image_classifier = PrescriptionImageClassifier()
stock_predictor = StockPredictor()
safety_predictor = SafetyPredictor()
disease_detector = DiseaseDetector()
pharmacy_locator = PharmacyLocator()
security_manager = SecurityManager()
encryption_manager = EncryptionManager()
chatbot = HealthcareChatbot(drug_matcher, generic_suggester, db_manager)
advanced_chatbot = AdvancedChatbot(drug_matcher, generic_suggester, db_manager)
# Initialize realtime tracker after socketio is created
realtime_tracker = RealtimeStockTracker(db_manager, stock_manager, socketio)

# Ensure upload directory exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs('uploads/processed', exist_ok=True)


@app.route('/')
def index():
    """Main dashboard page"""
    return render_template('index.html')


@app.route('/stock/search')
def stock_search():
    """Stock search page"""
    return render_template('stock_search.html')


@app.route('/dashboard')
def dashboard():
    """Advanced analytics dashboard"""
    return render_template('dashboard.html')


@app.route('/fraud-detection')
def fraud_detection():
    """Fraud detection feature page"""
    return render_template('fraud_detection.html')


@app.route('/login')
def login():
    """Login page"""
    return render_template('login.html')


@app.route('/register')
def register():
    """Register page"""
    return render_template('register.html')


@app.route('/api/upload-prescription', methods=['POST'])
def upload_prescription():
    """Upload and process prescription image"""
    try:
        if 'prescription' not in request.files:
            return jsonify({'error': 'No file uploaded'}), 400
        
        file = request.files['prescription']
        patient_id = request.form.get('patient_id', 'anonymous')
        location = request.form.get('location', '')
        
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        # Save uploaded file
        filename = secure_filename(f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{file.filename}")
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        # Encrypt and store
        encrypted_path = encryption_manager.encrypt_file(filepath)
        
        # Image Classification (CNN)
        image_classification = image_classifier.classify_image(filepath)
        
        # OCR Processing with enhanced error handling
        try:
            ocr_result = ocr_service.process_prescription(filepath)
        except Exception as ocr_error:
            # If OCR completely fails, create minimal result
            app.logger.warning(f"OCR processing error: {ocr_error}")
            ocr_result = {
                'raw_text': '',
                'confidence': 20,
                'doctor_name': '',
                'hospital_id': '',
                'hospital_name': '',
                'address': '',
                'phone': '',
                'date': '',
                'drugs': [],
                'dosage': [],
                'patient_name': '',
                'processing_method': 'error',
                'error': f'OCR processing failed: {str(ocr_error)}'
            }
        
        # Ensure OCR result has all required fields
        ocr_result.setdefault('raw_text', '')
        ocr_result.setdefault('confidence', 20)
        ocr_result.setdefault('doctor_name', '')
        ocr_result.setdefault('hospital_id', '')
        ocr_result.setdefault('hospital_name', '')
        ocr_result.setdefault('address', '')
        ocr_result.setdefault('phone', '')
        ocr_result.setdefault('date', '')
        ocr_result.setdefault('drugs', [])
        ocr_result.setdefault('patient_name', '')
        ocr_result.setdefault('processing_method', 'standard')
        
        # Extract drug names - use raw text if structured extraction failed
        extracted_drugs = ocr_result.get('drugs', [])
        
        # If no drugs extracted, try to extract from raw text
        if not extracted_drugs and ocr_result.get('raw_text'):
            raw_text = ocr_result.get('raw_text', '')
            # Look for capitalized words that might be drugs
            import re
            potential_drugs = re.findall(r'\b[A-Z][a-z]{3,}\b', raw_text)
            # Filter out common non-drug words
            skip_words = {'Doctor', 'Patient', 'Date', 'Hospital', 'Clinic', 'Medical', 'Center', 
                         'Name', 'Age', 'Address', 'Phone', 'Prescription', 'Medicine', 'Tablet',
                         'Prescribed', 'Dosage', 'Times', 'Daily', 'Weekly', 'Monthly'}
            extracted_drugs = [d for d in potential_drugs[:5] if d not in skip_words]
        
        # If still no drugs, use placeholder
        if not extracted_drugs:
            extracted_drugs = ['Prescription detected - drug names not extracted']
        
        # Match drugs with database
        matched_drugs = []
        unmatched_drugs = []
        for drug in extracted_drugs:
            if isinstance(drug, str) and drug.strip():
                match = drug_matcher.match_drug(drug)
                if match:
                    matched_drugs.append(match)
                else:
                    unmatched_drugs.append(drug)
        
        # Extract prescription metadata - Format matching expected output
        # Use raw_text for display if structured extraction is poor
        raw_text_preview = ocr_result.get('raw_text', '')[:200] if ocr_result.get('raw_text') else ''
        
        # Build drugs text - show matched and unmatched
        drugs_display = []
        if matched_drugs:
            drugs_display.extend([d.get('name', '') for d in matched_drugs])
        if unmatched_drugs:
            drugs_display.extend(unmatched_drugs[:3])  # Show first 3 unmatched
        
        prescription_data = {
            'patient_id': patient_id,
            'doctor_name': ocr_result.get('doctor_name', '') or 'Not found',
            'hospital_id': ocr_result.get('hospital_id', '') or 'Not found',
            'hospital_name': ocr_result.get('hospital_name', '') or ocr_result.get('hospital_id', '') or 'Not found',
            'address': ocr_result.get('address', '') or 'Not found',
            'phone': ocr_result.get('phone', '') or 'Not found',
            'date': ocr_result.get('date', '') or 'Not found',
            'patient_name': ocr_result.get('patient_name', '') or 'Not found',
            'drugs': matched_drugs,
            'unmatched_drugs': unmatched_drugs,
            'drugs_text': ', '.join(drugs_display) if drugs_display else (raw_text_preview or 'Not found'),
            'raw_text_preview': raw_text_preview,
            'ocr_confidence': max(40, min(95, ocr_result.get('confidence', 40))),  # Ensure reasonable range
            'location': location,
            'timestamp': datetime.now().isoformat(),
            'encrypted_path': encrypted_path,
            'image_classification': image_classification,
            'prescription_id': f"PRES_{datetime.now().strftime('%Y%m%d%H%M%S')}",
            'processing_method': ocr_result.get('processing_method', 'standard')
        }
        
        # AI Safety Prediction (with error handling)
        try:
            safety_prediction = safety_predictor.predict_safety(prescription_data)
            prescription_suggestions = safety_predictor.get_prescription_suggestions(prescription_data)
        except Exception as e:
            app.logger.warning(f"Safety prediction error: {e}")
            safety_prediction = {
                'is_safe': True,
                'safety_score': 0.5,
                'safety_level': 'MODERATE',
                'status_color': 'warning',
                'confidence': 0.5,
                'warnings': ['Unable to complete full safety analysis'],
                'suggestions': [],
                'predicted_diseases': [],
                'drug_count': len(matched_drugs),
                'interactions_detected': False
            }
            prescription_suggestions = {
                'predicted_diseases': [],
                'recommendations': [],
                'safety_tips': ['Please consult a healthcare professional for detailed analysis']
            }
        
        prescription_data['safety_prediction'] = safety_prediction
        prescription_data['prescription_suggestions'] = prescription_suggestions
        
        # Advanced Fraud Detection (Ensemble) - with error handling
        try:
            fraud_analysis = advanced_fraud_detector.detect_fraud_advanced(prescription_data)
        except Exception as e:
            app.logger.warning(f"Fraud detection error: {e}")
            fraud_analysis = {
                'fraud_score': 0.3,
                'is_fraud': False,
                'risk_level': 'LOW',
                'reasons': ['Analysis incomplete'],
                'risk_factors': [],
                'model_used': 'fallback'
            }
        
        prescription_data['fraud_score'] = float(fraud_analysis.get('fraud_score', 0.3))
        prescription_data['fraud_reasons'] = fraud_analysis.get('reasons', [])
        prescription_data['is_fraud'] = bool(fraud_analysis.get('is_fraud', False))
        prescription_data['risk_level'] = str(fraud_analysis.get('risk_level', 'LOW'))
        prescription_data['risk_factors'] = fraud_analysis.get('risk_factors', [])
        
        # Prescription Validation (Deep Learning) - with error handling
        try:
            validation_result = prescription_validator.validate(prescription_data)
        except Exception as e:
            app.logger.warning(f"Validation error: {e}")
            validation_result = {
                'score': 0.6,
                'status': 'pending',
                'confidence': 0.5
            }
        
        prescription_data['validation_score'] = float(validation_result.get('score', 0))
        prescription_data['validation_status'] = str(validation_result.get('status', 'pending'))
        
        # Store in database
        prescription_id = db_manager.save_prescription(prescription_data)
        prescription_data['prescription_id'] = prescription_id
        
        # Check stock availability with AI predictions
        stock_results = []
        for drug in matched_drugs:
            stock_info = stock_manager.check_availability(
                drug['drug_id'],
                location,
                radius_km=10
            )
            
            # Get real-time AI predictions
            realtime_status = realtime_tracker.get_realtime_status(
                drug['drug_id'],
                location
            )
            
            stock_results.append({
                'drug': drug,
                'stock': stock_info,
                'ai_prediction': realtime_status.get('prediction', {}),
                'demand_prediction': realtime_status.get('demand', {}),
                'restock_recommendation': realtime_status.get('restock', {}),
                'realtime': True
            })
        
        # Get generic alternatives
        generic_alternatives = []
        for drug in matched_drugs:
            generics = generic_suggester.suggest_generics(drug['drug_id'])
            generic_alternatives.append({
                'original': drug,
                'alternatives': generics
            })
        
        # Prepare response data and make it JSON serializable
        response_data = {
            'success': True,
            'prescription_id': str(prescription_id) if prescription_id else '',
            'prescription_data': make_json_serializable(prescription_data),
            'ocr_result': {
                'raw_text': str(ocr_result.get('raw_text', '')),
                'confidence': float(ocr_result.get('confidence', 0)),
                'processing_method': str(ocr_result.get('processing_method', 'standard')),
                'extracted_drugs': [str(d) for d in extracted_drugs] if extracted_drugs else [],
                'matched_drugs_count': int(len(matched_drugs)),
                'unmatched_drugs_count': int(len(unmatched_drugs))
            },
            'safety_prediction': make_json_serializable(safety_prediction),
            'prescription_suggestions': make_json_serializable(prescription_suggestions),
            'stock_availability': make_json_serializable(stock_results),
            'generic_alternatives': make_json_serializable(generic_alternatives),
            'fraud_detection': {
                'score': float(fraud_analysis.get('fraud_score', 0)),
                'is_fraud': bool(fraud_analysis.get('is_fraud', False)),
                'risk_level': str(fraud_analysis.get('risk_level', 'MEDIUM')),
                'reasons': [str(r) for r in fraud_analysis.get('reasons', [])],
                'risk_factors': make_json_serializable(fraud_analysis.get('risk_factors', {})),
                'model_used': str(fraud_analysis.get('model_used', 'ensemble'))
            },
            'image_classification': make_json_serializable(image_classification),
            'validation': make_json_serializable(validation_result)
        }
        
        return jsonify(response_data)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/check-stock', methods=['POST'])
def check_stock():
    """Check drug stock availability"""
    try:
        data = request.json
        drug_name = data.get('drug_name')
        location = data.get('location')
        radius_km = data.get('radius_km', 10)
        
        # Match drug
        drug_match = drug_matcher.match_drug(drug_name)
        if not drug_match:
            return jsonify({'error': 'Drug not found in database'}), 404
        
        # Check stock
        stock_info = stock_manager.check_availability(
            drug_match['drug_id'],
            location,
            radius_km
        )
        
        return jsonify({
            'success': True,
            'drug': drug_match,
            'stock': stock_info
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/search-drugs', methods=['GET'])
def search_drugs():
    """Search drugs in database"""
    try:
        query = request.args.get('q', '')
        limit = int(request.args.get('limit', 10))
        
        results = drug_matcher.search_drugs(query, limit)
        
        return jsonify({
            'success': True,
            'results': results
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/get-generics', methods=['POST'])
def get_generics():
    """Get generic alternatives for a drug"""
    try:
        data = request.json
        drug_id = data.get('drug_id')
        
        generics = generic_suggester.suggest_generics(drug_id)
        
        return jsonify({
            'success': True,
            'alternatives': generics
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/update-stock', methods=['POST'])
def update_stock():
    """Update pharmacy stock (for pharmacy users)"""
    try:
        data = request.json
        pharmacy_id = data.get('pharmacy_id')
        drug_id = data.get('drug_id')
        quantity = data.get('quantity')
        
        stock_manager.update_stock(pharmacy_id, drug_id, quantity)
        
        # Emit real-time update
        socketio.emit('stock_update', {
            'pharmacy_id': pharmacy_id,
            'drug_id': drug_id,
            'quantity': quantity,
            'timestamp': datetime.now().isoformat()
        })
        
        return jsonify({'success': True})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/fraud-analysis', methods=['POST'])
def fraud_analysis():
    """Get detailed fraud analysis"""
    try:
        data = request.json
        prescription_id = data.get('prescription_id')
        
        prescription = db_manager.get_prescription(prescription_id)
        if not prescription:
            return jsonify({'error': 'Prescription not found'}), 404
        
        # Advanced fraud analysis
        analysis = fraud_detector.detailed_analysis(prescription)
        
        return jsonify({
            'success': True,
            'analysis': analysis
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/dashboard-stats', methods=['GET'])
def dashboard_stats():
    """Get dashboard statistics"""
    try:
        stats = db_manager.get_dashboard_stats()
        
        return jsonify({
            'success': True,
            'stats': stats
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/detect-disease', methods=['POST'])
def detect_disease():
    """Detect disease from body/skin image and suggest doctors & medicines"""
    try:
        if 'disease_image' not in request.files:
            return jsonify({'error': 'No image uploaded'}), 400
        
        file = request.files['disease_image']
        patient_name = request.form.get('patient_name', 'anonymous')
        location = request.form.get('location', '')
        
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        # Save uploaded file
        filename = secure_filename(f"disease_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{file.filename}")
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        # Detect disease using CNN
        disease_result = disease_detector.detect_disease(filepath)
        
        # Find nearby doctors
        detected_disease = disease_result.get('detected_disease', 'unknown')
        nearby_doctors = disease_detector.find_nearby_doctors(detected_disease, location)
        
        # Prepare response
        response_data = {
            'success': True,
            'patient_name': str(patient_name),
            'location': str(location),
            'disease_detection': make_json_serializable(disease_result),
            'recommended_doctors': make_json_serializable(nearby_doctors),
            'timestamp': datetime.now().isoformat(),
            'image_path': str(filename)
        }
        
        return jsonify(response_data)
    
    except Exception as e:
        import traceback
        error_trace = traceback.format_exc()
        app.logger.error(f"Error detecting disease: {error_trace}")
        return jsonify({
            'success': False,
            'error': str(e),
            'message': 'Error detecting disease. Please try again with a different image.'
        }), 500


@app.route('/api/search-pharmacies', methods=['POST'])
def search_pharmacies():
    """Search pharmacies by city with detailed information"""
    try:
        data = request.json
        city = data.get('city', '')
        drug_name = data.get('drug_name', '')
        
        if not city:
            return jsonify({'error': 'City name is required'}), 400
        
        # Search pharmacies
        pharmacy_results = pharmacy_locator.search_pharmacies_by_city(city, drug_name)
        
        # Make JSON serializable
        response_data = {
            'success': True,
            'results': make_json_serializable(pharmacy_results)
        }
        
        return jsonify(response_data)
    
    except Exception as e:
        app.logger.error(f"Error searching pharmacies: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/chatbot', methods=['POST'])
def chatbot_endpoint():
    """Advanced Chatbot API endpoint"""
    try:
        data = request.json
        message = data.get('message', '')
        user_id = data.get('user_id', 'anonymous')
        context = data.get('context', {})
        use_advanced = data.get('advanced', True)  # Use advanced chatbot by default
        
        if not message:
            return jsonify({'error': 'Message is required'}), 400
        
        # Use advanced chatbot
        if use_advanced:
            response = advanced_chatbot.process_message(message, user_id, context)
        else:
            response = chatbot.process_message(message, user_id, context)
        
        return jsonify({
            'success': True,
            'intent': response['intent'],
            'response': response['response'],
            'confidence': response['confidence'],
            'suggestions': response.get('suggestions', [])
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/chatbot/history', methods=['GET'])
def chatbot_history():
    """Get chatbot conversation history"""
    try:
        user_id = request.args.get('user_id', 'anonymous')
        limit = int(request.args.get('limit', 10))
        use_advanced = request.args.get('advanced', 'true').lower() == 'true'
        
        if use_advanced:
            history = advanced_chatbot.get_conversation_history(user_id, limit)
        else:
            history = chatbot.get_conversation_history(user_id, limit)
        
        return jsonify({
            'success': True,
            'history': history
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@socketio.on('connect')
def handle_connect():
    """Handle WebSocket connection"""
    emit('connected', {'message': 'Connected to real-time updates'})


@socketio.on('chatbot_message')
def handle_chatbot_message(data):
    """Handle chatbot messages via WebSocket"""
    try:
        message = data.get('message', '')
        user_id = data.get('user_id', 'anonymous')
        context = data.get('context', {})
        
        if message:
            response = chatbot.process_message(message, user_id, context)
            emit('chatbot_response', {
                'intent': response['intent'],
                'response': response['response'],
                'confidence': response['confidence']
            })
    except Exception as e:
        emit('chatbot_error', {'error': str(e)})


@socketio.on('subscribe_stock')
def handle_subscribe_stock(data):
    """Subscribe to real-time stock updates for specific drugs"""
    from flask import request as flask_request
    drug_ids = data.get('drug_ids', [])
    socket_id = flask_request.sid
    
    for drug_id in drug_ids:
        realtime_tracker.subscribe(drug_id, socket_id)
    
    session['subscribed_drugs'] = drug_ids
    emit('subscribed', {'drug_ids': drug_ids, 'message': 'Subscribed to real-time updates'})


@socketio.on('unsubscribe_stock')
def handle_unsubscribe_stock(data):
    """Unsubscribe from stock updates"""
    from flask import request as flask_request
    drug_ids = data.get('drug_ids', [])
    socket_id = flask_request.sid
    
    for drug_id in drug_ids:
        realtime_tracker.unsubscribe(drug_id, socket_id)
    
    emit('unsubscribed', {'drug_ids': drug_ids})


@socketio.on('get_realtime_stock')
def handle_realtime_stock(data):
    """Get real-time stock status with AI predictions"""
    drug_id = data.get('drug_id')
    location = data.get('location', '')
    
    if drug_id:
        status = realtime_tracker.get_realtime_status(drug_id, location)
        emit('realtime_stock_status', status)


if __name__ == '__main__':
    # Initialize database with sample data
    db_manager.initialize_database()
    
    # Run Flask app (using port 5001 to avoid conflict with macOS AirPlay on 5000)
    port = int(os.environ.get('PORT', 5001))
    print(f"\n🚀 Starting server on http://localhost:{port}")
    print("📝 Open your browser and navigate to the URL above")
    socketio.run(app, host='0.0.0.0', port=port, debug=True)

