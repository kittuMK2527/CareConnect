"""
AI Safety Prediction Model
Predicts if a prescription is safe and provides disease/prescription suggestions
"""

import numpy as np
from typing import Dict, List
import json


class SafetyPredictor:
    """
    AI model to predict prescription safety
    Provides disease diagnosis suggestions and prescription recommendations
    """
    
    def __init__(self):
        # Disease-drug mapping (simplified knowledge base)
        self.disease_drug_mapping = {
            'fever': ['paracetamol', 'ibuprofen', 'aspirin'],
            'infection': ['amoxicillin', 'azithromycin', 'cefixime', 'levofloxacin'],
            'diabetes': ['metformin', 'insulin', 'glimepiride'],
            'hypertension': ['amlodipine', 'atenolol', 'losartan'],
            'pain': ['diclofenac', 'ibuprofen', 'paracetamol'],
            'cough': ['dextromethorphan', 'codeine', 'guaifenesin'],
            'cold': ['paracetamol', 'pseudoephedrine', 'chlorpheniramine'],
            'asthma': ['salbutamol', 'budesonide', 'montelukast'],
            'gastritis': ['omeprazole', 'ranitidine', 'pantoprazole'],
            'arthritis': ['diclofenac', 'ibuprofen', 'naproxen']
        }
        
        # Drug safety profiles
        self.drug_safety = {
            'paracetamol': {'safe': True, 'max_daily': 4000, 'interactions': []},
            'amoxicillin': {'safe': True, 'max_daily': 3000, 'interactions': ['antacids']},
            'metformin': {'safe': True, 'max_daily': 2550, 'interactions': ['alcohol']},
            'insulin': {'safe': True, 'max_daily': 100, 'interactions': ['alcohol']},
            'omeprazole': {'safe': True, 'max_daily': 80, 'interactions': ['warfarin']},
            'diclofenac': {'safe': False, 'max_daily': 150, 'interactions': ['aspirin', 'warfarin']},
            'ibuprofen': {'safe': False, 'max_daily': 2400, 'interactions': ['aspirin', 'warfarin']},
            'aspirin': {'safe': False, 'max_daily': 4000, 'interactions': ['warfarin', 'ibuprofen']}
        }
    
    def predict_safety(self, prescription_data: Dict) -> Dict:
        """
        Predict if prescription is safe
        Returns: safety prediction with confidence and reasons
        """
        drugs = prescription_data.get('drugs', [])
        drug_names = [d.get('name', '').lower() if isinstance(d, dict) else str(d).lower() for d in drugs]
        
        safety_score = 1.0
        warnings = []
        suggestions = []
        
        # Check drug interactions
        interactions = self._check_interactions(drug_names)
        if interactions:
            safety_score -= 0.3
            warnings.append(f"Potential drug interactions detected: {', '.join(interactions)}")
        
        # Check for unsafe drugs
        unsafe_drugs = [d for d in drug_names if d in self.drug_safety and not self.drug_safety[d]['safe']]
        if unsafe_drugs:
            safety_score -= 0.2
            warnings.append(f"Unsafe drugs detected: {', '.join(unsafe_drugs)}")
        
        # Check drug count (too many drugs might indicate issues)
        if len(drug_names) > 5:
            safety_score -= 0.1
            warnings.append("High number of drugs prescribed - review recommended")
        
        # Check if prescription has required fields
        if not prescription_data.get('doctor_name') or prescription_data.get('doctor_name') == 'Not found':
            safety_score -= 0.15
            warnings.append("Doctor name not found - prescription may be incomplete")
        
        if not prescription_data.get('hospital_id') or prescription_data.get('hospital_id') == 'Not found':
            safety_score -= 0.1
            warnings.append("Hospital/clinic information missing")
        
        # Predict disease based on drugs
        predicted_diseases = self._predict_disease(drug_names)
        
        # Generate suggestions
        if predicted_diseases:
            for disease in predicted_diseases:
                suggestions.append({
                    'type': 'disease',
                    'prediction': disease,
                    'confidence': 0.75,
                    'recommended_drugs': self.disease_drug_mapping.get(disease, [])
                })
        
        # Safety level
        if safety_score >= 0.8:
            safety_level = 'SAFE'
            status_color = 'success'
        elif safety_score >= 0.6:
            safety_level = 'MODERATE'
            status_color = 'warning'
        else:
            safety_level = 'UNSAFE'
            status_color = 'danger'
        
        return {
            'is_safe': safety_score >= 0.7,
            'safety_score': round(safety_score, 2),
            'safety_level': safety_level,
            'status_color': status_color,
            'confidence': round(min(safety_score + 0.1, 1.0), 2),
            'warnings': warnings,
            'suggestions': suggestions,
            'predicted_diseases': predicted_diseases,
            'drug_count': len(drug_names),
            'interactions_detected': len(interactions) > 0
        }
    
    def _check_interactions(self, drug_names: List[str]) -> List[str]:
        """Check for drug interactions"""
        interactions = []
        for i, drug1 in enumerate(drug_names):
            if drug1 in self.drug_safety:
                for drug2 in drug_names[i+1:]:
                    if drug2 in self.drug_safety:
                        if drug2 in self.drug_safety[drug1].get('interactions', []):
                            interactions.append(f"{drug1} + {drug2}")
        return interactions
    
    def _predict_disease(self, drug_names: List[str]) -> List[str]:
        """Predict disease based on prescribed drugs"""
        disease_scores = {}
        
        for disease, common_drugs in self.disease_drug_mapping.items():
            score = 0
            for drug in drug_names:
                if any(common_drug in drug for common_drug in common_drugs):
                    score += 1
            if score > 0:
                disease_scores[disease] = score
        
        # Return top 2 predicted diseases
        sorted_diseases = sorted(disease_scores.items(), key=lambda x: x[1], reverse=True)
        return [d[0] for d in sorted_diseases[:2]]
    
    def get_prescription_suggestions(self, prescription_data: Dict) -> Dict:
        """
        Get comprehensive prescription suggestions
        Returns: disease predictions, drug recommendations, safety tips
        """
        drugs = prescription_data.get('drugs', [])
        drug_names = [d.get('name', '').lower() if isinstance(d, dict) else str(d).lower() for d in drugs]
        
        # Predict disease
        predicted_diseases = self._predict_disease(drug_names)
        
        # Get recommendations
        recommendations = []
        for disease in predicted_diseases:
            recommended_drugs = self.disease_drug_mapping.get(disease, [])
            recommendations.append({
                'disease': disease.title(),
                'description': self._get_disease_description(disease),
                'recommended_drugs': recommended_drugs,
                'alternative_treatments': self._get_alternative_treatments(disease)
            })
        
        # Safety tips
        safety_tips = []
        if len(drug_names) > 3:
            safety_tips.append("Multiple medications - ensure proper spacing between doses")
        
        interactions = self._check_interactions(drug_names)
        if interactions:
            safety_tips.append("Consult doctor about drug interactions before taking")
        
        return {
            'predicted_diseases': predicted_diseases,
            'recommendations': recommendations,
            'safety_tips': safety_tips,
            'drug_count': len(drug_names)
        }
    
    def _get_disease_description(self, disease: str) -> str:
        """Get disease description"""
        descriptions = {
            'fever': 'Elevated body temperature, often a symptom of infection',
            'infection': 'Bacterial or viral infection requiring antibiotics',
            'diabetes': 'Metabolic disorder affecting blood sugar levels',
            'hypertension': 'High blood pressure condition',
            'pain': 'Physical discomfort or ache',
            'cough': 'Respiratory symptom, may indicate cold or infection',
            'cold': 'Common viral infection of upper respiratory tract',
            'asthma': 'Chronic respiratory condition',
            'gastritis': 'Inflammation of stomach lining',
            'arthritis': 'Joint inflammation and pain'
        }
        return descriptions.get(disease, 'Medical condition requiring treatment')
    
    def _get_alternative_treatments(self, disease: str) -> List[str]:
        """Get alternative treatment suggestions"""
        alternatives = {
            'fever': ['Rest', 'Hydration', 'Cool compress'],
            'infection': ['Antibiotics', 'Rest', 'Proper hygiene'],
            'diabetes': ['Diet control', 'Exercise', 'Regular monitoring'],
            'hypertension': ['Low salt diet', 'Exercise', 'Stress management'],
            'pain': ['Rest', 'Ice/Heat therapy', 'Physical therapy'],
            'cough': ['Hydration', 'Honey', 'Steam inhalation'],
            'cold': ['Rest', 'Hydration', 'Vitamin C'],
            'asthma': ['Inhaler', 'Avoid triggers', 'Regular checkups'],
            'gastritis': ['Diet modification', 'Avoid spicy food', 'Small frequent meals'],
            'arthritis': ['Physical therapy', 'Exercise', 'Weight management']
        }
        return alternatives.get(disease, ['Consult doctor', 'Follow prescription'])

