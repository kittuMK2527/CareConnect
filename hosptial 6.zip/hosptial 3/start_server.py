#!/usr/bin/env python3
"""
Server startup script with error handling
"""

import sys
import os

def check_dependencies():
    """Check if all required packages are installed"""
    required = {
        'flask': 'flask',
        'flask_cors': 'flask_cors',
        'flask_socketio': 'flask_socketio',
        'pymongo': 'pymongo',
        'opencv-python': 'cv2',
        'pytesseract': 'pytesseract',
        'numpy': 'numpy',
        'pandas': 'pandas',
        'scikit-learn': 'sklearn',
        'xgboost': 'xgboost'
    }
    
    missing = []
    for package_name, import_name in required.items():
        try:
            __import__(import_name)
        except ImportError:
            missing.append(package_name)
    
    if missing:
        print("❌ Missing dependencies:")
        for pkg in missing:
            print(f"   - {pkg}")
        print("\nInstall with: pip install -r requirements.txt")
        return False
    
    return True

def main():
    """Main startup function"""
    print("=" * 60)
    print("🚀 Starting AI-Powered Drug Availability System")
    print("=" * 60)
    print()
    
    # Check dependencies
    if not check_dependencies():
        sys.exit(1)
    
    print("✅ All dependencies installed")
    print()
    
    # Import and start app
    try:
        from app import app, socketio, db_manager
        
        print("✅ App imported successfully")
        print("✅ Initializing database...")
        db_manager.initialize_database()
        print("✅ Database initialized")
        print()
        
        port = int(os.environ.get('PORT', 5001))
        print("=" * 60)
        print(f"🌐 Server starting on http://localhost:{port}")
        print("=" * 60)
        print()
        print("📝 Features available:")
        print("   • Prescription upload & fraud detection")
        print("   • Real-time stock tracking")
        print("   • AI-powered predictions")
        print("   • Healthcare chatbot")
        print()
        print("Press Ctrl+C to stop the server")
        print("=" * 60)
        print()
        
        socketio.run(app, host='0.0.0.0', port=port, debug=True)
        
    except KeyboardInterrupt:
        print("\n\n👋 Server stopped by user")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ Error starting server: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == '__main__':
    main()

