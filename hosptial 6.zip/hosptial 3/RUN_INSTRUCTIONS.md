# 🚀 How to Run the System

## Quick Start

### Option 1: Simple Start
```bash
python app.py
```

### Option 2: Using Startup Script
```bash
python start_server.py
```

## Access the Application

Once started, open your browser:
- **URL**: http://localhost:5001
- **Port**: 5001 (to avoid conflict with macOS AirPlay on port 5000)

## What to Expect

When you run the server, you should see:
```
🚀 Starting server on http://localhost:5001
📝 Open your browser and navigate to the URL above
```

## Troubleshooting

### If you see "ImportError"
Install missing dependencies:
```bash
pip install -r requirements.txt
```

### If port 5001 is already in use
Change the port in `app.py`:
```python
port = int(os.environ.get('PORT', 5002))  # Change 5001 to 5002
```

Or set environment variable:
```bash
PORT=5002 python app.py
```

### MongoDB Connection Error
This is **normal** if MongoDB is not installed. The system will use in-memory storage and work fine.

### TensorFlow Warnings
If you see "TensorFlow not available" warnings, the system will use simplified models. To enable full ML features:
```bash
pip install tensorflow
```

## Features Available

Once running, you can:
1. ✅ Upload prescriptions
2. ✅ Get fraud detection
3. ✅ Check stock availability
4. ✅ Use AI chatbot
5. ✅ Get real-time stock updates
6. ✅ View AI predictions

## Stopping the Server

Press `Ctrl+C` in the terminal where the server is running.

---

**Status**: ✅ Ready to Run
**Last Updated**: 2024-2025

