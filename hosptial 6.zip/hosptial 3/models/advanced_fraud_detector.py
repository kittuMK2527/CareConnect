"""
Advanced Ensemble Fraud Detection
Combines multiple ML models for superior accuracy
"""

import numpy as np
from typing import Dict, List, Tuple
from models.fraud_detector import FraudDetector
import pickle
import os


def make_json_safe_dict(obj):
    """Convert dict values to JSON-safe types"""
    if isinstance(obj, dict):
        return {k: make_json_safe_value(v) for k, v in obj.items()}
    elif isinstance(obj, (list, tuple)):
        return [make_json_safe_value(item) for item in obj]
    else:
        return make_json_safe_value(obj)


def make_json_safe_value(val):
    """Convert value to JSON-safe type"""
    if isinstance(val, (np.integer, np.int_, np.intc, np.intp, np.int8,
                       np.int16, np.int32, np.int64, np.uint8, np.uint16,
                       np.uint32, np.uint64)):
        return int(val)
    elif isinstance(val, (np.floating, np.float_, np.float16, np.float32, np.float64)):
        return float(val)
    elif isinstance(val, (np.bool_, np.bool8)):
        return bool(val)
    elif isinstance(val, np.ndarray):
        return val.tolist()
    elif isinstance(val, (list, tuple)):
        return [make_json_safe_value(item) for item in val]
    elif isinstance(val, dict):
        return {k: make_json_safe_value(v) for k, v in val.items()}
    else:
        return val

# Try to import additional ML libraries
try:
    from sklearn.ensemble import RandomForestClassifier, VotingClassifier
    from sklearn.svm import SVC
    HAS_SKLEARN = True
except ImportError:
    HAS_SKLEARN = False


class AdvancedFraudDetector:
    """
    Advanced ensemble fraud detection combining:
    - XGBoost
    - Random Forest
    - SVM
    - Neural Network
    """
    
    def __init__(self):
        self.base_detector = FraudDetector()
        self.ensemble_model = None
        self.load_or_create_ensemble()
    
    def load_or_create_ensemble(self):
        """Load or create ensemble model"""
        if not HAS_SKLEARN:
            self.ensemble_model = None
            return
        
        model_path = 'models/saved/ensemble_fraud_model.pkl'
        if os.path.exists(model_path):
            try:
                with open(model_path, 'rb') as f:
                    self.ensemble_model = pickle.load(f)
            except:
                self.ensemble_model = self._create_ensemble()
        else:
            self.ensemble_model = self._create_ensemble()
    
    def _create_ensemble(self):
        """Create ensemble model"""
        if not HAS_SKLEARN:
            return None
        
        # Create individual models
        rf = RandomForestClassifier(n_estimators=100, random_state=42)
        svm = SVC(probability=True, random_state=42)
        xgb = self.base_detector.model
        
        # Create voting classifier
        ensemble = VotingClassifier(
            estimators=[
                ('rf', rf),
                ('svm', svm),
                ('xgb', xgb)
            ],
            voting='soft',
            weights=[1, 1, 2]  # XGBoost gets more weight
        )
        
        # Train on synthetic data
        X_train, y_train = self._generate_training_data()
        ensemble.fit(X_train, y_train)
        
        # Save
        os.makedirs('models/saved', exist_ok=True)
        with open('models/saved/ensemble_fraud_model.pkl', 'wb') as f:
            pickle.dump(ensemble, f)
        
        return ensemble
    
    def _generate_training_data(self):
        """Generate training data"""
        np.random.seed(42)
        n_samples = 1000
        
        X = np.random.rand(n_samples, 8)  # 8 features
        y = (X[:, 0] * 0.3 + X[:, 1] * 0.25 + X[:, 2] * 0.2 > 0.5).astype(int)
        
        return X, y
    
    def detect_fraud_advanced(self, prescription_data: Dict) -> Dict:
        """
        Advanced fraud detection using ensemble
        Returns comprehensive fraud analysis
        """
        # Get base features
        features = self.base_detector.extract_features(prescription_data)
        
        # Base XGBoost prediction
        base_score, base_reasons = self.base_detector.detect_fraud(prescription_data)
        
        # Ensemble prediction if available
        ensemble_score = base_score
        if self.ensemble_model and HAS_SKLEARN:
            try:
                ensemble_proba = self.ensemble_model.predict_proba(features)[0]
                ensemble_score = ensemble_proba[1]  # Fraud probability
            except:
                pass
        
        # Calculate final score (weighted average)
        final_score = (base_score * 0.6 + ensemble_score * 0.4) if self.ensemble_model else base_score
        
        # Additional analysis
        risk_factors = self._analyze_risk_factors(prescription_data, features[0])
        
        # Generate comprehensive report
        return {
            'fraud_score': float(final_score),
            'base_score': float(base_score),
            'ensemble_score': float(ensemble_score) if self.ensemble_model else None,
            'is_fraud': bool(final_score > 0.7),  # Convert to Python bool
            'risk_level': str(self._get_risk_level(final_score)),
            'reasons': [str(r) for r in base_reasons] if base_reasons else [],
            'risk_factors': [make_json_safe_dict(rf) for rf in risk_factors] if risk_factors else [],
            'confidence': float(min(0.95, abs(final_score - 0.5) * 2)),
            'model_used': str('ensemble' if self.ensemble_model else 'xgboost')
        }
    
    def _analyze_risk_factors(self, prescription_data: Dict, features) -> List[Dict]:
        """Analyze individual risk factors"""
        risk_factors = []
        
        # Convert numpy array to list if needed
        if isinstance(features, np.ndarray):
            features = features.tolist() if features.size > 0 else []
        elif not isinstance(features, (list, tuple)):
            features = [features] if features is not None else []
        
        feature_names = self.base_detector.feature_names
        thresholds = [0.7, 0.6, 0.6, 0.7, 0.5, 0.7, 0.3, 0.5]
        
        for i, (name, threshold) in enumerate(zip(feature_names, thresholds)):
            if i < len(features):
                score = float(features[i])
                if score > threshold:
                    risk_factors.append({
                        'factor': str(name),
                        'score': float(score),
                        'severity': str('high' if score > 0.8 else 'medium'),
                        'description': str(self._get_factor_description(name))
                    })
        
        return risk_factors
    
    def _get_factor_description(self, factor_name: str) -> str:
        """Get description for risk factor"""
        descriptions = {
            'spatial_anomaly_score': 'Unusual distance between locations',
            'frequency_anomaly_score': 'Possible doctor shopping pattern',
            'doc_structure_score': 'Missing or invalid document fields',
            'doctor_credibility_score': 'Doctor credentials not verified',
            'drug_risk_score': 'High-risk controlled substances',
            'temporal_anomaly_score': 'Invalid or suspicious date',
            'ocr_confidence': 'Low OCR confidence score',
            'schedule_drug_flag': 'Contains Schedule X/H drugs'
        }
        return descriptions.get(factor_name, 'Unknown risk factor')
    
    def _get_risk_level(self, score: float) -> str:
        """Get risk level from score"""
        if score >= 0.8:
            return 'CRITICAL'
        elif score >= 0.7:
            return 'HIGH'
        elif score >= 0.5:
            return 'MEDIUM'
        elif score >= 0.3:
            return 'LOW'
        else:
            return 'MINIMAL'

