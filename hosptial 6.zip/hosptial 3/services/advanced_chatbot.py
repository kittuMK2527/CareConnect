"""
Advanced AI Chatbot with NLP and Context Understanding
Enhanced version with better natural language processing
"""

import re
from typing import Dict, List, Optional, Tuple
from datetime import datetime
import json
from services.drug_matcher import DrugMatcher
from services.generic_suggester import GenericSuggester
from database.db_manager import DatabaseManager


class AdvancedChatbot:
    """
    Advanced AI-powered chatbot with:
    - Context-aware conversations
    - Multi-turn dialogue
    - Sentiment analysis
    - Better intent recognition
    - Drug interaction checking
    - Prescription guidance
    """
    
    def __init__(self, drug_matcher: DrugMatcher, generic_suggester: GenericSuggester, db_manager: DatabaseManager):
        self.drug_matcher = drug_matcher
        self.generic_suggester = generic_suggester
        self.db_manager = db_manager
        self.conversation_history = {}
        self.user_contexts = {}  # Store user context
        
        # Enhanced intent patterns with more variations
        self.intent_patterns = {
            'drug_search': [
                r'search.*drug', r'find.*drug', r'looking.*for.*drug',
                r'where.*find', r'available.*drug', r'stock.*drug',
                r'need.*medicine', r'want.*medicine', r'buy.*drug'
            ],
            'drug_info': [
                r'what.*is', r'tell.*about', r'information.*about',
                r'details.*of', r'know.*about', r'explain',
                r'what.*does', r'how.*works', r'uses.*of'
            ],
            'generic_alternative': [
                r'generic', r'cheaper', r'alternative', r'jan.*aushadhi',
                r'low.*cost', r'affordable', r'save.*money',
                r'cheap.*version', r'budget.*option'
            ],
            'prescription_help': [
                r'prescription', r'verify', r'check.*prescription',
                r'fraud', r'valid', r'authentic', r'fake',
                r'upload.*prescription', r'scan.*prescription'
            ],
            'stock_check': [
                r'stock', r'available', r'in.*stock', r'have.*stock',
                r'pharmacy.*has', r'where.*buy', r'can.*get',
                r'find.*nearby', r'location'
            ],
            'side_effects': [
                r'side.*effect', r'adverse', r'risk', r'warning',
                r'precaution', r'safe', r'harmful', r'danger'
            ],
            'dosage': [
                r'dosage', r'how.*much', r'how.*many', r'take',
                r'consume', r'dose', r'quantity', r'amount'
            ],
            'interaction': [
                r'interaction', r'mix', r'together', r'combine',
                r'both.*take', r'with.*other', r'conflict'
            ],
            'greeting': [
                r'hello', r'hi', r'hey', r'good.*morning', r'good.*evening',
                r'help', r'assist', r'start', r'begin'
            ],
            'goodbye': [
                r'bye', r'goodbye', r'thank.*you', r'thanks', r'see.*you',
                r'done', r'finish', r'exit'
            ],
            'prescription_upload': [
                r'upload', r'scan', r'verify.*prescription', r'check.*prescription',
                r'process.*prescription', r'analyze.*prescription'
            ]
        }
    
    def process_message(self, message: str, user_id: str = 'anonymous', context: Dict = None) -> Dict:
        """
        Process user message with advanced NLP
        Returns: chatbot response with intent and data
        """
        message_lower = message.lower().strip()
        
        # Get or create user context
        if user_id not in self.user_contexts:
            self.user_contexts[user_id] = {
                'location': '',
                'previous_drugs': [],
                'conversation_topic': None,
                'last_intent': None
            }
        
        user_context = self.user_contexts[user_id]
        if context:
            user_context.update(context)
        
        # Detect intent with confidence
        intent, confidence = self._detect_intent_advanced(message_lower, user_context)
        
        # Generate response
        response = self._generate_advanced_response(message_lower, intent, confidence, user_context)
        
        # Update context
        user_context['last_intent'] = intent
        if intent in ['drug_search', 'drug_info']:
            drug_name = self._extract_drug_name(message_lower)
            if drug_name:
                user_context['previous_drugs'].append(drug_name)
        
        # Store conversation
        if user_id not in self.conversation_history:
            self.conversation_history[user_id] = []
        
        self.conversation_history[user_id].append({
            'message': message,
            'intent': intent,
            'response': response['text'],
            'timestamp': datetime.now().isoformat(),
            'confidence': confidence
        })
        
        return {
            'intent': intent,
            'response': response,
            'confidence': confidence,
            'suggestions': response.get('suggestions', [])
        }
    
    def _detect_intent_advanced(self, message: str, context: Dict) -> Tuple[str, float]:
        """Advanced intent detection with confidence scoring"""
        scores = {}
        
        for intent, patterns in self.intent_patterns.items():
            score = 0
            matches = 0
            for pattern in patterns:
                if re.search(pattern, message, re.IGNORECASE):
                    matches += 1
                    score += 1.0 / len(patterns)  # Weighted scoring
            
            # Context boost
            if context.get('last_intent') == intent:
                score += 0.2  # Continuation boost
            
            if score > 0:
                scores[intent] = score
        
        if scores:
            best_intent = max(scores, key=scores.get)
            confidence = min(1.0, scores[best_intent])
            return best_intent, confidence
        
        return 'general', 0.5
    
    def _generate_advanced_response(self, message: str, intent: str, confidence: float, context: Dict) -> Dict:
        """Generate advanced response with context awareness"""
        
        if intent == 'greeting':
            return {
                'text': "👋 Hello! I'm your advanced AI healthcare assistant.\n\n"
                       "I can help you with:\n"
                       "🔍 **Drug Search** - Find medicines and check availability\n"
                       "💊 **Drug Information** - Get details about medications\n"
                       "💰 **Generic Alternatives** - Find affordable Jan Aushadhi options\n"
                       "📋 **Prescription Verification** - Check prescription authenticity\n"
                       "📦 **Stock Availability** - Find nearby pharmacies\n"
                       "⚠️ **Side Effects & Interactions** - Safety information\n"
                       "💡 **Dosage Guidance** - Usage instructions\n\n"
                       "What would you like to know?",
                'type': 'text',
                'confidence': confidence,
                'suggestions': ['Search for a drug', 'Check prescription', 'Find generic alternatives']
            }
        
        elif intent == 'prescription_upload':
            return {
                'text': "📋 I can help you verify prescriptions!\n\n"
                       "**To verify a prescription:**\n"
                       "1. Go to the main page\n"
                       "2. Click 'Upload Prescription'\n"
                       "3. Upload your prescription image\n"
                       "4. I'll analyze it using:\n"
                       "   • Advanced OCR (Text extraction)\n"
                       "   • CNN Image Classification\n"
                       "   • ML Fraud Detection\n"
                       "   • Deep Learning Validation\n\n"
                       "The system will check:\n"
                       "✅ Doctor verification\n"
                       "✅ Hospital/clinic verification\n"
                       "✅ Drug extraction\n"
                       "✅ Fraud detection\n"
                       "✅ Stock availability\n\n"
                       "Would you like to upload a prescription now?",
                'type': 'text',
                'confidence': confidence,
                'suggestions': ['Upload prescription', 'How does verification work?']
            }
        
        elif intent == 'drug_search':
            drug_name = self._extract_drug_name(message)
            if drug_name:
                results = self.drug_matcher.search_drugs(drug_name, limit=5)
                if results:
                    response_text = f"🔍 Found **{len(results)}** results for '{drug_name}':\n\n"
                    for i, drug in enumerate(results[:3], 1):
                        response_text += f"**{i}. {drug['name']}**\n"
                        response_text += f"   Category: {drug.get('category', 'Unknown')}\n"
                        if drug.get('schedule'):
                            response_text += f"   Schedule: {drug['schedule']}\n"
                        response_text += "\n"
                    
                    response_text += "Would you like:\n"
                    response_text += "• More details about any drug?\n"
                    response_text += "• Check stock availability?\n"
                    response_text += "• Find generic alternatives?"
                    
                    return {
                        'text': response_text,
                        'data': results,
                        'type': 'drug_list',
                        'confidence': confidence,
                        'suggestions': ['Check stock', 'Get details', 'Find generics']
                    }
                else:
                    return {
                        'text': f"❌ Sorry, I couldn't find '{drug_name}' in our database.\n\n"
                               "**Suggestions:**\n"
                               "• Check the spelling\n"
                               "• Try the generic name instead of brand name\n"
                               "• Use common drug names\n\n"
                               "Example: Try 'Paracetamol' instead of 'Crocin'",
                        'type': 'text',
                        'confidence': confidence
                    }
            else:
                return {
                    'text': "🔍 I'd be happy to help you search for a drug!\n\n"
                           "**Please tell me:**\n"
                           "• The drug name (e.g., 'Paracetamol', 'Insulin')\n"
                           "• Or describe what you need (e.g., 'medicine for fever')\n\n"
                           "I'll search our database and find the best matches.",
                    'type': 'text',
                    'confidence': confidence
                }
        
        elif intent == 'generic_alternative':
            drug_name = self._extract_drug_name(message)
            if drug_name:
                match = self.drug_matcher.match_drug(drug_name)
                if match:
                    generics = self.generic_suggester.suggest_generics(match['drug_id'])
                    if generics:
                        response_text = f"💰 **Affordable Alternatives for {match['name']}:**\n\n"
                        total_savings = 0
                        for alt in generics:
                            savings_pct = alt.get('savings', '50-80%')
                            response_text += f"💊 **{alt['name']}**\n"
                            response_text += f"   Price: ₹{alt['price']}\n"
                            response_text += f"   Savings: {savings_pct}\n"
                            response_text += f"   Source: {alt.get('source', 'Jan Aushadhi')}\n\n"
                        
                        response_text += "💡 **Tip:** These are available through Jan Aushadhi stores.\n"
                        response_text += "You can save 50-80% compared to branded medicines!"
                        
                        return {
                            'text': response_text,
                            'data': {'original': match, 'alternatives': generics},
                            'type': 'generic_alternatives',
                            'confidence': confidence,
                            'suggestions': ['Find nearby stores', 'More alternatives']
                        }
                    else:
                        return {
                            'text': f"ℹ️ {match['name']} is already a generic medicine, or no cheaper alternatives are available at the moment.",
                            'type': 'text',
                            'confidence': confidence
                        }
                else:
                    return {
                        'text': f"❓ Could you please provide the exact drug name? I couldn't match '{drug_name}'.\n\n"
                               "**Try:**\n"
                               "• Generic name (e.g., 'Paracetamol')\n"
                               "• Brand name (e.g., 'Crocin')\n"
                               "• Or search first: 'Search for [drug name]'",
                        'type': 'text',
                        'confidence': confidence
                    }
            else:
                return {
                    'text': "💰 I can help you find affordable generic alternatives!\n\n"
                           "**Please tell me:**\n"
                           "• The drug name you're currently using\n"
                           "• Or ask: 'Generic for [drug name]'\n\n"
                           "I'll suggest Jan Aushadhi alternatives that can save you 50-80%!",
                    'type': 'text',
                    'confidence': confidence
                }
        
        elif intent == 'prescription_help':
            return {
                'text': "📋 **Prescription Verification Help**\n\n"
                       "Our AI system verifies prescriptions using:\n\n"
                       "**1. OCR Processing** 📸\n"
                       "   • Extracts text from prescription image\n"
                       "   • Identifies doctor, hospital, drugs, date\n"
                       "   • Confidence scoring\n\n"
                       "**2. Image Classification** 🖼️\n"
                       "   • CNN model analyzes image authenticity\n"
                       "   • Detects fake/printed prescriptions\n\n"
                       "**3. Fraud Detection** 🛡️\n"
                       "   • XGBoost + Ensemble ML models\n"
                       "   • Checks for:\n"
                       "     - Doctor shopping patterns\n"
                       "     - Spatial anomalies\n"
                       "     - Document structure\n"
                       "     - Temporal issues\n\n"
                       "**4. Validation** ✅\n"
                       "   • Deep learning validation\n"
                       "   • Risk factor analysis\n\n"
                       "**To verify:** Upload prescription on main page!",
                'type': 'text',
                'confidence': confidence,
                'suggestions': ['Upload prescription', 'How accurate is it?']
            }
        
        elif intent == 'interaction':
            return {
                'text': "⚠️ **Drug Interaction Check**\n\n"
                       "I can help check drug interactions, but for safety:\n\n"
                       "**Always consult a doctor or pharmacist** before:\n"
                       "• Taking multiple medicines together\n"
                       "• Starting new medications\n"
                       "• Combining prescription and OTC drugs\n\n"
                       "**Common interactions to watch:**\n"
                       "• Blood thinners + Aspirin\n"
                       "• Antacids + Antibiotics\n"
                       "• Alcohol + Medications\n\n"
                       "For detailed interaction checking, please consult a healthcare professional.",
                'type': 'text',
                'confidence': confidence
            }
        
        elif intent == 'goodbye':
            return {
                'text': "👋 Thank you for using our healthcare assistant!\n\n"
                       "**Remember:**\n"
                       "• Always consult doctors for medical advice\n"
                       "• Verify prescriptions before use\n"
                       "• Check drug interactions\n"
                       "• Use generic alternatives when possible\n\n"
                       "Stay healthy! 😊\n\n"
                       "Feel free to come back anytime!",
                'type': 'text',
                'confidence': confidence
            }
        
        else:
            # General/unknown - use context
            if context.get('last_intent'):
                return {
                    'text': "I'm here to help! Could you rephrase your question?\n\n"
                           "Or try:\n"
                           "• 'Search for [drug name]'\n"
                           "• 'Generic for [drug name]'\n"
                           "• 'Check prescription'\n"
                           "• 'Stock availability'\n\n"
                           "What would you like to know?",
                    'type': 'text',
                    'confidence': 0.6,
                    'suggestions': ['Search drugs', 'Check prescription', 'Find generics']
                }
            else:
                return {
                    'text': "🤖 I'm your advanced AI healthcare assistant!\n\n"
                           "I can help with:\n"
                           "🔍 Drug search and information\n"
                           "💰 Generic alternatives (save 50-80%)\n"
                           "📋 Prescription verification\n"
                           "📦 Stock availability\n"
                           "⚠️ Safety information\n\n"
                           "**What would you like to do?**\n"
                           "Just ask me naturally!",
                    'type': 'text',
                    'confidence': 0.7,
                    'suggestions': ['Search drugs', 'Verify prescription', 'Find generics']
                }
    
    def _extract_drug_name(self, message: str) -> Optional[str]:
        """Enhanced drug name extraction"""
        # Remove common words
        stop_words = ['search', 'find', 'looking', 'for', 'need', 'want', 'buy', 'get', 'medicine', 'drug', 'pill']
        words = [w for w in message.split() if w.lower() not in stop_words]
        
        # Look for capitalized words (common drug names)
        for i, word in enumerate(words):
            if word and word[0].isupper() and len(word) > 3:
                # Try single word
                potential = word
                match = self.drug_matcher.match_drug(potential)
                if match:
                    return potential
                
                # Try two words
                if i + 1 < len(words) and words[i + 1][0].isupper():
                    potential = f"{word} {words[i + 1]}"
                    match = self.drug_matcher.match_drug(potential)
                    if match:
                        return potential
        
        # Try common drug keywords
        drug_keywords = ['paracetamol', 'amoxicillin', 'metformin', 'insulin', 
                        'omeprazole', 'atorvastatin', 'amlodipine', 'aspirin',
                        'ibuprofen', 'diclofenac', 'cefixime', 'azithromycin']
        message_lower = message.lower()
        for keyword in drug_keywords:
            if keyword in message_lower:
                return keyword
        
        return None
    
    def get_conversation_history(self, user_id: str = 'anonymous', limit: int = 10) -> List[Dict]:
        """Get conversation history"""
        return self.conversation_history.get(user_id, [])[-limit:]
    
    def clear_context(self, user_id: str):
        """Clear user context"""
        if user_id in self.user_contexts:
            self.user_contexts[user_id] = {
                'location': '',
                'previous_drugs': [],
                'conversation_topic': None,
                'last_intent': None
            }

