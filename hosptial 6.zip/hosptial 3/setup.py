"""
Setup script for the project
Run this to initialize the database and create necessary directories
"""

import os
import sys
from database.db_manager import DatabaseManager

def setup_project():
    """Initialize project directories and database"""
    print("🚀 Setting up AI-Powered Drug Availability & Prescription Fraud Detection System...")
    
    # Create necessary directories
    directories = [
        'models/saved',
        'data',
        'uploads/prescriptions',
        'uploads/encrypted',
        'uploads/processed',
        'templates'
    ]
    
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
        print(f"✓ Created directory: {directory}")
    
    # Initialize database
    print("\n📊 Initializing database...")
    try:
        db_manager = DatabaseManager()
        db_manager.initialize_database()
        print("✓ Database initialized successfully")
    except Exception as e:
        print(f"⚠ Database initialization skipped: {e}")
        print("  (System will work with in-memory storage)")
    
    print("\n✅ Setup complete!")
    print("\n📝 Next steps:")
    print("  1. Install Tesseract OCR (if not already installed)")
    print("  2. Run: python app.py")
    print("  3. Open browser: http://localhost:5000")
    print("\n💡 For MongoDB (optional):")
    print("  - Install MongoDB")
    print("  - Set MONGODB_URI environment variable")

if __name__ == '__main__':
    setup_project()

