# 🧪 Testing Guide - Frontend

## ✅ How to Test

### 1. Start the Server
```bash
python app.py
```

You should see:
```
🚀 Starting server on http://localhost:5001
📝 Open your browser and navigate to the URL above
```

### 2. Open Browser
Go to: **http://localhost:5001**

### 3. Test Features

#### ✅ Home Page
- [ ] Header displays correctly
- [ ] Navigation links work
- [ ] Hero section shows
- [ ] Stats cards display
- [ ] Features section shows

#### ✅ Upload Prescription
- [ ] Click upload area → file picker opens
- [ ] Drag & drop image → file selected
- [ ] Select file → shows file name
- [ ] Click "Verify Prescription" → processes
- [ ] Results display correctly

#### ✅ Results Display
- [ ] Alert banner shows (SUSPICIOUS/VERIFIED)
- [ ] Fraud score displays (e.g., "84.0%")
- [ ] Prescription details card shows:
  - Doctor Name
  - Hospital/Clinic
  - Prescription ID
  - Date
  - Medicines
- [ ] Verification status shows:
  - Doctor Verification (✓ or ✗)
  - Hospital Verification (✓ or ✗)
- [ ] OCR Confidence bar displays

#### ✅ Stock Search
- [ ] Go to: http://localhost:5001/stock/search
- [ ] Enter medicine name
- [ ] Click Search
- [ ] Results display

### 4. Check Browser Console

Press **F12** to open developer tools:

**Console Tab:**
- Should see: "Page loaded, initializing..."
- Should see: "Upload area initialized"
- No red errors

**Network Tab:**
- `/api/upload-prescription` → 200 OK
- `/api/dashboard-stats` → 200 OK

## 🐛 Troubleshooting

### If Upload Doesn't Work:
1. Check browser console (F12)
2. Look for JavaScript errors
3. Verify file input exists: `document.getElementById('prescriptionFile')`

### If Results Don't Show:
1. Check Network tab for API response
2. Verify response has `success: true`
3. Check `displayResults()` function

### If Stats Don't Load:
1. Check `/api/dashboard-stats` endpoint
2. Verify response format
3. Check `loadStats()` function

## 📝 Expected Behavior

1. **Page Load:**
   - All elements visible
   - No console errors
   - Stats load automatically

2. **File Upload:**
   - Click → File picker opens
   - Drag & drop → File selected
   - Shows file name

3. **Processing:**
   - Shows loading spinner
   - Processes with AI models
   - Shows results

4. **Results:**
   - Alert banner with status
   - Fraud score percentage
   - All details displayed
   - Verification status shown

---

**Status**: ✅ Tested and Working
**Last Updated**: 2024-2025

