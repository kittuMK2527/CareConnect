"""
XGBoost-based Fraud Detection Engine
Implements ensemble learning for prescription fraud detection
"""

import numpy as np
import pandas as pd
import xgboost as xgb
import pickle
import os
from datetime import datetime
from typing import Dict, List, Tuple
import json


class FraudDetector:
    """
    Advanced fraud detection using XGBoost and feature engineering
    """
    
    def __init__(self, model_path='models/saved/fraud_model.pkl'):
        self.model_path = model_path
        self.model = None
        self.feature_names = [
            'spatial_anomaly_score',
            'frequency_anomaly_score',
            'doc_structure_score',
            'doctor_credibility_score',
            'drug_risk_score',
            'temporal_anomaly_score',
            'ocr_confidence',
            'schedule_drug_flag'
        ]
        self.load_or_create_model()
    
    def load_or_create_model(self):
        """Load existing model or create new one"""
        if os.path.exists(self.model_path):
            try:
                with open(self.model_path, 'rb') as f:
                    self.model = pickle.load(f)
            except:
                self.model = self._create_model()
        else:
            self.model = self._create_model()
    
    def _create_model(self):
        """Create and train XGBoost model"""
        # Initialize XGBoost classifier
        model = xgb.XGBClassifier(
            n_estimators=100,
            max_depth=6,
            learning_rate=0.1,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=42,
            eval_metric='logloss'
        )
        
        # Train on synthetic data (in production, use real training data)
        X_train, y_train = self._generate_training_data()
        model.fit(X_train, y_train)
        
        # Save model
        os.makedirs(os.path.dirname(self.model_path), exist_ok=True)
        with open(self.model_path, 'wb') as f:
            pickle.dump(model, f)
        
        return model
    
    def _generate_training_data(self):
        """Generate synthetic training data"""
        np.random.seed(42)
        n_samples = 1000
        
        # Generate features
        X = np.random.rand(n_samples, len(self.feature_names))
        
        # Generate labels (fraud = 1, legitimate = 0)
        # Higher scores indicate higher fraud probability
        fraud_prob = (
            X[:, 0] * 0.3 +  # spatial anomaly
            X[:, 1] * 0.25 +  # frequency anomaly
            X[:, 2] * 0.2 +   # doc structure
            X[:, 3] * 0.15 +  # doctor credibility
            X[:, 4] * 0.1     # drug risk
        )
        y = (fraud_prob > 0.5).astype(int)
        
        return X, y
    
    def extract_features(self, prescription_data: Dict) -> np.ndarray:
        """Extract features from prescription data"""
        features = []
        
        # 1. Spatial Anomaly Score
        # Distance between patient home, clinic, and pharmacy
        location = prescription_data.get('location', '')
        spatial_score = self._calculate_spatial_anomaly(location)
        features.append(spatial_score)
        
        # 2. Frequency Anomaly Score (Doctor Shopping)
        patient_id = prescription_data.get('patient_id', '')
        frequency_score = self._calculate_frequency_anomaly(patient_id, prescription_data)
        features.append(frequency_score)
        
        # 3. Document Structure Score
        doc_score = self._calculate_doc_structure_score(prescription_data)
        features.append(doc_score)
        
        # 4. Doctor Credibility Score
        doctor_name = prescription_data.get('doctor_name', '')
        hospital_id = prescription_data.get('hospital_id', '')
        doctor_score = self._calculate_doctor_credibility(doctor_name, hospital_id)
        features.append(doctor_score)
        
        # 5. Drug Risk Score
        drugs = prescription_data.get('drugs', [])
        drug_risk = self._calculate_drug_risk_score(drugs)
        features.append(drug_risk)
        
        # 6. Temporal Anomaly Score
        date = prescription_data.get('date', '')
        temporal_score = self._calculate_temporal_anomaly(date)
        features.append(temporal_score)
        
        # 7. OCR Confidence
        ocr_confidence = prescription_data.get('ocr_confidence', 0) / 100.0
        features.append(ocr_confidence)
        
        # 8. Schedule Drug Flag
        schedule_flag = 1.0 if self._has_schedule_drugs(drugs) else 0.0
        features.append(schedule_flag)
        
        return np.array(features).reshape(1, -1)
    
    def _calculate_spatial_anomaly(self, location: str) -> float:
        """Calculate spatial anomaly score based on location patterns"""
        # In production, use actual geolocation data
        # For now, return random score (0-1)
        return np.random.rand()
    
    def _calculate_frequency_anomaly(self, patient_id: str, prescription_data: Dict) -> float:
        """Detect doctor shopping patterns"""
        # Check if patient visited multiple doctors for same drug
        # Higher score = more suspicious
        if patient_id == 'anonymous':
            return 0.3
        
        # In production, query database for patient history
        # For now, return moderate score
        return np.random.uniform(0.2, 0.6)
    
    def _calculate_doc_structure_score(self, prescription_data: Dict) -> float:
        """Score based on document structure and required fields"""
        score = 0.0
        
        # Check for required fields
        if not prescription_data.get('doctor_name'):
            score += 0.3
        if not prescription_data.get('hospital_id'):
            score += 0.3
        if not prescription_data.get('date'):
            score += 0.2
        
        # OCR confidence affects structure score
        ocr_conf = prescription_data.get('ocr_confidence', 0)
        if ocr_conf < 70:
            score += 0.2
        
        return min(score, 1.0)
    
    def _calculate_doctor_credibility(self, doctor_name: str, hospital_id: str) -> float:
        """Calculate doctor credibility score"""
        # In production, verify against medical council database
        # Lower score = more credible
        if not doctor_name or not hospital_id:
            return 0.8  # High risk if missing
        
        # Check if doctor exists in database
        # For now, return random score
        return np.random.uniform(0.1, 0.4)
    
    def _calculate_drug_risk_score(self, drugs: List[Dict]) -> float:
        """Calculate risk based on drug types"""
        if not drugs:
            return 0.0
        
        risk_score = 0.0
        schedule_x_drugs = ['Morphine', 'Fentanyl', 'Oxycodone', 'Codeine']
        
        for drug in drugs:
            drug_name = drug.get('name', '').lower()
            
            # Check for Schedule X/H drugs
            if any(sched in drug_name for sched in schedule_x_drugs):
                risk_score += 0.5
            
            # Check for high-risk categories
            if 'narcotic' in drug_name or 'controlled' in drug_name:
                risk_score += 0.3
        
        return min(risk_score / len(drugs) if drugs else 0, 1.0)
    
    def _calculate_temporal_anomaly(self, date: str) -> float:
        """Detect temporal anomalies (future dates, very old dates)"""
        if not date:
            return 0.5
        
        try:
            presc_date = datetime.strptime(date, '%Y-%m-%d')
            today = datetime.now()
            
            # Future date = suspicious
            if presc_date > today:
                return 0.9
            
            # Very old date = suspicious
            days_diff = (today - presc_date).days
            if days_diff > 90:
                return 0.7
            
            return 0.1
        except:
            return 0.5
    
    def _has_schedule_drugs(self, drugs: List[Dict]) -> bool:
        """Check if prescription contains Schedule X/H drugs"""
        schedule_keywords = ['schedule x', 'schedule h', 'narcotic', 'controlled']
        for drug in drugs:
            drug_name = drug.get('name', '').lower()
            if any(keyword in drug_name for keyword in schedule_keywords):
                return True
        return False
    
    def detect_fraud(self, prescription_data: Dict) -> Tuple[float, List[str]]:
        """
        Detect fraud in prescription
        Returns: (fraud_score, list_of_reasons)
        """
        # Extract features
        features = self.extract_features(prescription_data)
        
        # Predict fraud probability
        fraud_prob = self.model.predict_proba(features)[0][1]
        
        # Generate reasons
        reasons = self._generate_fraud_reasons(prescription_data, features[0])
        
        return fraud_prob, reasons
    
    def _generate_fraud_reasons(self, prescription_data: Dict, features: np.ndarray) -> List[str]:
        """Generate explainable AI reasons for fraud detection"""
        reasons = []
        
        if features[0] > 0.7:  # spatial_anomaly_score
            reasons.append("Spatial anomaly detected: Unusual distance between patient location and clinic")
        
        if features[1] > 0.6:  # frequency_anomaly_score
            reasons.append("Frequency anomaly: Possible doctor shopping pattern detected")
        
        if features[2] > 0.6:  # doc_structure_score
            reasons.append("Document structure issue: Missing required fields or low OCR confidence")
        
        if features[3] > 0.7:  # doctor_credibility_score
            reasons.append("Doctor credibility: Hospital Registration ID not found in National Database")
        
        if features[4] > 0.5:  # drug_risk_score
            reasons.append("High-risk drugs: Prescription contains Schedule X/H controlled substances")
        
        if features[5] > 0.7:  # temporal_anomaly_score
            reasons.append("Temporal anomaly: Prescription date is invalid (future or very old)")
        
        if not reasons:
            reasons.append("No significant fraud indicators detected")
        
        return reasons
    
    def detailed_analysis(self, prescription: Dict) -> Dict:
        """Perform detailed fraud analysis"""
        features = self.extract_features(prescription)
        fraud_score, reasons = self.detect_fraud(prescription)
        
        return {
            'fraud_score': float(fraud_score),
            'is_fraud': fraud_score > 0.7,
            'reasons': reasons,
            'feature_scores': {
                'spatial_anomaly': float(features[0][0]),
                'frequency_anomaly': float(features[0][1]),
                'document_structure': float(features[0][2]),
                'doctor_credibility': float(features[0][3]),
                'drug_risk': float(features[0][4]),
                'temporal_anomaly': float(features[0][5]),
                'ocr_confidence': float(features[0][6]),
                'schedule_drug_flag': float(features[0][7])
            },
            'recommendation': 'REJECT' if fraud_score > 0.7 else 'REVIEW' if fraud_score > 0.5 else 'APPROVE'
        }

