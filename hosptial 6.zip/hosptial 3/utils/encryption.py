"""
Encryption Manager
Handles AES-256 encryption for prescription images
"""

from cryptography.fernet import Fernet
import os
import base64


class EncryptionManager:
    """
    Handles file encryption using AES-256 (Fernet)
    """
    
    def __init__(self, key_path='data/encryption_key.key'):
        self.key_path = key_path
        self.key = self._load_or_generate_key()
        self.cipher = Fernet(self.key)
    
    def _load_or_generate_key(self) -> bytes:
        """Load existing key or generate new one"""
        if os.path.exists(self.key_path):
            with open(self.key_path, 'rb') as f:
                return f.read()
        else:
            # Generate new key
            key = Fernet.generate_key()
            os.makedirs(os.path.dirname(self.key_path), exist_ok=True)
            with open(self.key_path, 'wb') as f:
                f.write(key)
            return key
    
    def encrypt_file(self, file_path: str) -> str:
        """Encrypt file and return encrypted file path"""
        try:
            with open(file_path, 'rb') as f:
                file_data = f.read()
            
            encrypted_data = self.cipher.encrypt(file_data)
            
            # Save encrypted file
            encrypted_path = file_path.replace('prescriptions', 'encrypted')
            os.makedirs(os.path.dirname(encrypted_path), exist_ok=True)
            
            with open(encrypted_path, 'wb') as f:
                f.write(encrypted_data)
            
            # Optionally delete original (for security)
            # os.remove(file_path)
            
            return encrypted_path
        except Exception as e:
            print(f"Encryption error: {e}")
            return file_path
    
    def decrypt_file(self, encrypted_path: str) -> bytes:
        """Decrypt file and return decrypted data"""
        try:
            with open(encrypted_path, 'rb') as f:
                encrypted_data = f.read()
            
            decrypted_data = self.cipher.decrypt(encrypted_data)
            return decrypted_data
        except Exception as e:
            print(f"Decryption error: {e}")
            return b''

